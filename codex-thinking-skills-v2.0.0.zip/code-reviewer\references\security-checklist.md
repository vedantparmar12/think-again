# Security Review Checklist

A comprehensive guide for reviewing code security issues.

## Input Validation

- [ ] All user input is validated before processing
- [ ] Whitelist validation used (not blacklist)
- [ ] Input length limits enforced
- [ ] File uploads validate type, size, and content
- [ ] URL parameters sanitized before use

## Authentication & Authorization

- [ ] Passwords hashed with strong algorithm (bcrypt, Argon2)
- [ ] No hardcoded credentials
- [ ] Session tokens are cryptographically random
- [ ] Proper session timeout configured
- [ ] Authorization checks on every protected route
- [ ] JWT tokens validated properly (signature, expiry, claims)
- [ ] Multi-factor authentication for sensitive operations

## Injection Vulnerabilities

### SQL Injection
- [ ] Parameterized queries or ORM used (no string concatenation)
- [ ] Stored procedures use parameters
- [ ] Least privilege database user

### Command Injection
- [ ] No shell execution with user input
- [ ] If shell needed, use parameterized alternatives
- [ ] Input strictly validated against allowlist

### XSS (Cross-Site Scripting)
- [ ] User content HTML-escaped before rendering
- [ ] Content Security Policy (CSP) headers set
- [ ] No `innerHTML` with user data
- [ ] Framework auto-escaping enabled (React, Vue, etc.)

## Data Protection

- [ ] Sensitive data encrypted at rest
- [ ] HTTPS enforced (no HTTP)
- [ ] Secrets stored in environment variables or vault
- [ ] No sensitive data in logs
- [ ] PII handled according to privacy regulations
- [ ] Secure random number generation for security purposes

## CSRF Protection

- [ ] Anti-CSRF tokens on state-changing operations
- [ ] SameSite cookie attribute set
- [ ] Referer/Origin header validation

## Error Handling

- [ ] No sensitive information in error messages
- [ ] Stack traces not exposed to users
- [ ] Proper logging of security events
- [ ] Rate limiting on authentication endpoints

## API Security

- [ ] API keys not exposed in client code
- [ ] Rate limiting implemented
- [ ] CORS properly configured (not `*` in production)
- [ ] Request size limits enforced
- [ ] API versioning implemented

## Dependencies

- [ ] No known vulnerable dependencies (check npm audit, safety, etc.)
- [ ] Dependencies kept up to date
- [ ] Supply chain attack mitigation (lock files, SRI)

## Common Pitfalls

1. **Trusting client-side validation only** - Always validate server-side
2. **Using weak random generators** - Use crypto-grade for security tokens
3. **Storing passwords in plain text** - Always hash
4. **Exposing internal errors** - Generic messages to users, detailed logs internally
5. **Missing authorization checks** - Check on every request, not just routes
