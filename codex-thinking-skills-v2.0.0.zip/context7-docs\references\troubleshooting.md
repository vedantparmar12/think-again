# Context7 Troubleshooting Guide

## Common Issues

### "Library not found" (404)

**Symptoms:** Getting 404 error when fetching docs

**Solutions:**
1. Run search first to find the exact library ID:
   ```bash
   python3 scripts/context7_fetch.py search "library-name"
   ```
2. Check the ID format - must start with `/` (e.g., `/vercel/next.js`)
3. Library might not be indexed yet - check https://context7.com for available libraries

### "Documentation not finalized"

**Symptoms:** Library exists but docs return empty

**Cause:** Library is being indexed or parsed

**Solution:** Wait 5-10 minutes and retry. New libraries take time to process.

### Rate Limiting (429)

**Symptoms:** "Too many requests" errors

**Solutions:**
1. Add API key to environment:
   ```bash
   export CONTEXT7_API_KEY="your-key"
   ```
2. Reduce request frequency
3. Cache responses locally for repeated queries

### Connection Timeouts

**Symptoms:** Requests hang or time out

**Solutions:**
1. Check internet connectivity
2. Try again - API might be under heavy load
3. If behind proxy, set `https_proxy` environment variable

### Wrong Version Docs

**Symptoms:** Documentation doesn't match your library version

**Solutions:**
1. Specify exact version in library ID:
   ```bash
   python3 scripts/context7_fetch.py docs "/vercel/next.js/v14.2.0"
   ```
2. Search to see available versions:
   ```bash
   python3 scripts/context7_fetch.py search "next.js"
   ```

## Debugging Tips

### Check if API is reachable
```bash
curl -I https://api.context7.com/v1/search?q=react
```

### Verify API key is set
```bash
echo $CONTEXT7_API_KEY
```

### Test with verbose output
```bash
python3 -u scripts/context7_fetch.py search "react" 2>&1
```

## Getting Help

- GitHub Issues: https://github.com/upstash/context7/issues
- Email: context7@upstash.com
- Dashboard: https://context7.com/dashboard
