# Python Code Review Checklist

Python-specific items to check during code reviews.

## Code Style & Conventions

- [ ] Follows PEP 8 style guide
- [ ] Snake_case for functions and variables
- [ ] PascalCase for classes
- [ ] UPPER_CASE for constants
- [ ] Docstrings for modules, classes, and public functions
- [ ] Type hints used (especially in public APIs)

## Common Issues

### Resource Management
```python
# Bad - file might not close if error occurs
file = open('data.txt')
data = file.read()
file.close()

# Good - context manager ensures cleanup
with open('data.txt') as file:
    data = file.read()
```

### Mutable Default Arguments
```python
# Bad - list is shared across calls
def add_item(item, items=[]):
    items.append(item)
    return items

# Good - use None and create new list
def add_item(item, items=None):
    if items is None:
        items = []
    items.append(item)
    return items
```

### Exception Handling
```python
# Bad - bare except catches everything
try:
    risky_operation()
except:
    pass

# Good - catch specific exceptions
try:
    risky_operation()
except ValueError as e:
    logger.error(f"Invalid value: {e}")
    raise
```

## Performance

- [ ] List comprehensions used instead of loops where appropriate
- [ ] Generator expressions for large datasets
- [ ] `in` operator used with sets/dicts (not lists) for membership tests
- [ ] String joining with `.join()` not `+` in loops
- [ ] `__slots__` for classes with many instances
- [ ] Database queries outside loops (avoid N+1)

## Security

- [ ] No `eval()` or `exec()` with user input
- [ ] `subprocess` uses lists, not shell=True with strings
- [ ] SQL uses parameterized queries
- [ ] Secrets from environment, not hardcoded
- [ ] pickle only used with trusted data
- [ ] Input validation on all external data

## Best Practices

### Use Built-ins
```python
# Instead of manually checking
if len(my_list) > 0:

# Use truthiness
if my_list:
```

### Dictionary get()
```python
# Instead of
if key in my_dict:
    value = my_dict[key]
else:
    value = default

# Use get()
value = my_dict.get(key, default)
```

### Pathlib
```python
# Instead of os.path
import os
path = os.path.join(dir, 'file.txt')

# Use pathlib
from pathlib import Path
path = Path(dir) / 'file.txt'
```

## Testing

- [ ] Tests use pytest or unittest
- [ ] Fixtures for test data
- [ ] Mocks for external dependencies
- [ ] Test coverage > 80% for critical code
- [ ] Tests are isolated and repeatable

## Async Code

- [ ] `async/await` used correctly
- [ ] No blocking I/O in async functions
- [ ] Async context managers for resources
- [ ] Proper error handling in coroutines
- [ ] asyncio.gather() for concurrent operations

## Type Hints

```python
from typing import List, Dict, Optional, Union

def process_data(
    items: List[str],
    config: Dict[str, any],
    timeout: Optional[int] = None
) -> Union[str, None]:
    ...
```

## Red Flags

1. Global variables modified inside functions
2. Circular imports
3. Star imports (`from module import *`)
4. Mixing tabs and spaces
5. Very long functions (>50 lines usually needs breaking up)
6. Deep nesting (>3-4 levels)
7. Complex list comprehensions (better as loop for readability)
