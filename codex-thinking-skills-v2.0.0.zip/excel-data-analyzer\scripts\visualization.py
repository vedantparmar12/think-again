"""
Visualization Module for Excel/CSV Analysis
Provides chart and graph generation functions for data visualization
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from typing import Union, List, Optional, Dict, Any, Tuple


# Set default style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (10, 6)
plt.rcParams['figure.dpi'] = 100


def create_chart(
    df: pd.DataFrame,
    chart_type: str,
    x: Optional[str] = None,
    y: Optional[Union[str, List[str]]] = None,
    title: Optional[str] = None,
    xlabel: Optional[str] = None,
    ylabel: Optional[str] = None,
    figsize: Tuple[int, int] = (10, 6),
    color: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> plt.Figure:
    """
    Universal chart creator supporting multiple chart types.

    Args:
        df: DataFrame containing the data
        chart_type: Type of chart - 'line', 'bar', 'scatter', 'pie', 'histogram',
                   'box', 'heatmap', 'area'
        x: Column for x-axis
        y: Column(s) for y-axis
        title: Chart title
        xlabel: X-axis label
        ylabel: Y-axis label
        figsize: Figure size as (width, height)
        color: Color(s) for the plot
        **kwargs: Additional arguments for specific chart types

    Returns:
        Matplotlib Figure object

    Examples:
        >>> fig = create_chart(df, 'line', x='Date', y='Sales', title='Sales Over Time')
        >>> fig = create_chart(df, 'bar', x='Product', y='Revenue')
        >>> fig = create_chart(df, 'scatter', x='Age', y='Income', color='blue')
    """
    fig, ax = plt.subplots(figsize=figsize)

    chart_type = chart_type.lower()

    if chart_type == 'line':
        if isinstance(y, list):
            for col in y:
                ax.plot(df[x], df[col], label=col, **kwargs)
            ax.legend()
        else:
            ax.plot(df[x], df[y], color=color, **kwargs)

    elif chart_type == 'bar':
        if isinstance(y, list):
            df.plot(x=x, y=y, kind='bar', ax=ax, color=color, **kwargs)
        else:
            ax.bar(df[x], df[y], color=color or 'steelblue', **kwargs)

    elif chart_type == 'barh' or chart_type == 'horizontal_bar':
        if isinstance(y, list):
            df.plot(x=x, y=y, kind='barh', ax=ax, color=color, **kwargs)
        else:
            ax.barh(df[x], df[y], color=color or 'steelblue', **kwargs)

    elif chart_type == 'scatter':
        scatter_kwargs = {k: v for k, v in kwargs.items() if k in ['s', 'alpha', 'marker']}
        ax.scatter(df[x], df[y], color=color or 'steelblue', **scatter_kwargs)

    elif chart_type == 'pie':
        ax.pie(df[y], labels=df[x], autopct='%1.1f%%', colors=color, **kwargs)
        ax.axis('equal')

    elif chart_type == 'histogram':
        bins = kwargs.pop('bins', 30)
        ax.hist(df[y], bins=bins, color=color or 'steelblue', edgecolor='black', **kwargs)

    elif chart_type == 'box':
        if isinstance(y, list):
            df[y].plot(kind='box', ax=ax, **kwargs)
        else:
            ax.boxplot(df[y], **kwargs)

    elif chart_type == 'heatmap':
        # For heatmap, df should be a pivot table or correlation matrix
        sns.heatmap(df, ax=ax, cmap=color or 'coolwarm', annot=True, fmt='.2f', **kwargs)

    elif chart_type == 'area':
        if isinstance(y, list):
            df.plot(x=x, y=y, kind='area', ax=ax, alpha=0.5, **kwargs)
        else:
            ax.fill_between(df[x], df[y], alpha=0.5, color=color or 'steelblue', **kwargs)

    else:
        raise ValueError(f"Unsupported chart type: {chart_type}")

    # Set labels and title
    if title:
        ax.set_title(title, fontsize=14, fontweight='bold')
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=11)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=11)

    plt.tight_layout()
    return fig


def create_multi_chart(
    df: pd.DataFrame,
    charts_config: List[Dict[str, Any]],
    layout: Optional[Tuple[int, int]] = None,
    figsize: Tuple[int, int] = (15, 10),
    suptitle: Optional[str] = None
) -> plt.Figure:
    """
    Create multiple charts in a single figure (dashboard).

    Args:
        df: DataFrame containing the data
        charts_config: List of chart configurations, each containing:
                      - chart_type: Type of chart
                      - x, y: Data columns
                      - title: Chart title
                      - other chart-specific kwargs
        layout: Grid layout as (rows, cols). Auto-calculated if None
        figsize: Overall figure size
        suptitle: Overall figure title

    Returns:
        Matplotlib Figure object

    Example:
        >>> config = [
        ...     {'chart_type': 'line', 'x': 'Date', 'y': 'Sales', 'title': 'Sales Trend'},
        ...     {'chart_type': 'bar', 'x': 'Product', 'y': 'Revenue', 'title': 'Revenue by Product'},
        ...     {'chart_type': 'pie', 'x': 'Category', 'y': 'Count', 'title': 'Distribution'}
        ... ]
        >>> fig = create_multi_chart(df, config, layout=(2, 2))
    """
    n_charts = len(charts_config)

    if layout is None:
        # Auto-calculate layout
        cols = int(np.ceil(np.sqrt(n_charts)))
        rows = int(np.ceil(n_charts / cols))
        layout = (rows, cols)

    fig, axes = plt.subplots(layout[0], layout[1], figsize=figsize)

    if n_charts == 1:
        axes = [axes]
    else:
        axes = axes.flatten()

    for idx, config in enumerate(charts_config):
        ax = axes[idx]
        chart_type = config.pop('chart_type')
        x = config.pop('x', None)
        y = config.pop('y', None)
        chart_title = config.pop('title', None)
        color = config.pop('color', None)

        # Create chart on specific axis
        plt.sca(ax)

        if chart_type == 'line':
            if isinstance(y, list):
                for col in y:
                    ax.plot(df[x], df[col], label=col, **config)
                ax.legend()
            else:
                ax.plot(df[x], df[y], color=color, **config)

        elif chart_type == 'bar':
            if isinstance(y, list):
                df.plot(x=x, y=y, kind='bar', ax=ax, color=color, **config)
            else:
                ax.bar(df[x], df[y], color=color or 'steelblue', **config)

        elif chart_type == 'scatter':
            ax.scatter(df[x], df[y], color=color or 'steelblue', **config)

        elif chart_type == 'pie':
            ax.pie(df[y], labels=df[x], autopct='%1.1f%%', colors=color, **config)
            ax.axis('equal')

        elif chart_type == 'histogram':
            bins = config.pop('bins', 30)
            ax.hist(df[y], bins=bins, color=color or 'steelblue', edgecolor='black', **config)

        elif chart_type == 'box':
            if isinstance(y, list):
                df[y].plot(kind='box', ax=ax, **config)
            else:
                ax.boxplot(df[y], **config)

        if chart_title:
            ax.set_title(chart_title, fontsize=12, fontweight='bold')

    # Hide extra subplots
    for idx in range(n_charts, len(axes)):
        axes[idx].set_visible(False)

    if suptitle:
        fig.suptitle(suptitle, fontsize=16, fontweight='bold')

    plt.tight_layout()
    return fig


def create_correlation_heatmap(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    title: str = 'Correlation Heatmap',
    figsize: Tuple[int, int] = (10, 8),
    annot: bool = True,
    cmap: str = 'coolwarm'
) -> plt.Figure:
    """
    Create a correlation heatmap for numeric columns.

    Args:
        df: DataFrame
        columns: Specific columns to include (all numeric if None)
        title: Chart title
        figsize: Figure size
        annot: Whether to annotate cells with values
        cmap: Color map

    Returns:
        Matplotlib Figure object
    """
    if columns:
        corr = df[columns].corr()
    else:
        corr = df.select_dtypes(include=[np.number]).corr()

    fig, ax = plt.subplots(figsize=figsize)
    sns.heatmap(corr, annot=annot, fmt='.2f', cmap=cmap, center=0,
                square=True, linewidths=1, cbar_kws={"shrink": 0.8}, ax=ax)

    ax.set_title(title, fontsize=14, fontweight='bold')
    plt.tight_layout()
    return fig


def create_distribution_plot(
    df: pd.DataFrame,
    column: str,
    kind: str = 'hist',
    title: Optional[str] = None,
    bins: int = 30,
    kde: bool = True,
    figsize: Tuple[int, int] = (10, 6)
) -> plt.Figure:
    """
    Create distribution plot for a column.

    Args:
        df: DataFrame
        column: Column to plot
        kind: Type - 'hist', 'kde', 'box', 'violin'
        title: Chart title
        bins: Number of bins for histogram
        kde: Whether to overlay KDE on histogram
        figsize: Figure size

    Returns:
        Matplotlib Figure object
    """
    fig, ax = plt.subplots(figsize=figsize)

    if kind == 'hist':
        ax.hist(df[column], bins=bins, edgecolor='black', alpha=0.7)
        if kde:
            ax2 = ax.twinx()
            df[column].plot(kind='kde', ax=ax2, color='red', linewidth=2)
            ax2.set_ylabel('Density')

    elif kind == 'kde':
        df[column].plot(kind='kde', ax=ax, linewidth=2)

    elif kind == 'box':
        ax.boxplot(df[column])

    elif kind == 'violin':
        parts = ax.violinplot([df[column].dropna()], showmeans=True, showmedians=True)

    ax.set_title(title or f'Distribution of {column}', fontsize=14, fontweight='bold')
    ax.set_xlabel(column)
    if kind == 'hist':
        ax.set_ylabel('Frequency')

    plt.tight_layout()
    return fig


def create_time_series_plot(
    df: pd.DataFrame,
    date_column: str,
    value_columns: Union[str, List[str]],
    title: str = 'Time Series',
    rolling_window: Optional[int] = None,
    figsize: Tuple[int, int] = (12, 6)
) -> plt.Figure:
    """
    Create time series plot with optional rolling average.

    Args:
        df: DataFrame
        date_column: Column containing dates
        value_columns: Column(s) to plot
        title: Chart title
        rolling_window: Window size for rolling average
        figsize: Figure size

    Returns:
        Matplotlib Figure object
    """
    fig, ax = plt.subplots(figsize=figsize)

    # Ensure date column is datetime
    df_plot = df.copy()
    df_plot[date_column] = pd.to_datetime(df_plot[date_column])
    df_plot = df_plot.sort_values(date_column)

    if isinstance(value_columns, str):
        value_columns = [value_columns]

    for col in value_columns:
        ax.plot(df_plot[date_column], df_plot[col], label=col, marker='o', markersize=4)

        if rolling_window:
            rolling = df_plot[col].rolling(window=rolling_window).mean()
            ax.plot(df_plot[date_column], rolling, label=f'{col} (MA{rolling_window})',
                   linestyle='--', linewidth=2)

    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xlabel('Date')
    ax.set_ylabel('Value')
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.xticks(rotation=45)
    plt.tight_layout()
    return fig


def save_chart(
    fig: plt.Figure,
    output_path: Union[str, Path],
    dpi: int = 300,
    bbox_inches: str = 'tight',
    **kwargs
) -> Path:
    """
    Save chart to file.

    Args:
        fig: Matplotlib Figure object
        output_path: Output file path (.png, .pdf, .jpg, .svg)
        dpi: Resolution (dots per inch)
        bbox_inches: Bounding box adjustment
        **kwargs: Additional arguments for savefig

    Returns:
        Path to saved file
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fig.savefig(output_path, dpi=dpi, bbox_inches=bbox_inches, **kwargs)
    plt.close(fig)

    return output_path


def create_comparison_chart(
    df: pd.DataFrame,
    categories: str,
    values: List[str],
    chart_type: str = 'bar',
    title: str = 'Comparison',
    figsize: Tuple[int, int] = (12, 6)
) -> plt.Figure:
    """
    Create comparison chart for multiple metrics across categories.

    Args:
        df: DataFrame
        categories: Column for categories (x-axis)
        values: List of columns to compare
        chart_type: 'bar' or 'line'
        title: Chart title
        figsize: Figure size

    Returns:
        Matplotlib Figure object
    """
    fig, ax = plt.subplots(figsize=figsize)

    if chart_type == 'bar':
        df.plot(x=categories, y=values, kind='bar', ax=ax)
    elif chart_type == 'line':
        df.plot(x=categories, y=values, kind='line', ax=ax, marker='o')

    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xlabel(categories)
    ax.set_ylabel('Value')
    ax.legend(title='Metrics')
    ax.grid(True, alpha=0.3)

    plt.xticks(rotation=45)
    plt.tight_layout()
    return fig


if __name__ == "__main__":
    # Example usage
    print("Visualization Module - Example Usage")
    print("=" * 50)

    # Create sample data
    np.random.seed(42)
    dates = pd.date_range('2024-01-01', periods=100)
    sample_df = pd.DataFrame({
        'Date': dates,
        'Sales': np.random.randint(100, 500, 100) + np.arange(100) * 2,
        'Revenue': np.random.randint(1000, 5000, 100) + np.arange(100) * 10,
        'Customers': np.random.randint(50, 200, 100)
    })

    print("\nCreating sample charts...")

    # Line chart
    fig1 = create_chart(sample_df, 'line', x='Date', y='Sales',
                       title='Sales Trend', xlabel='Date', ylabel='Sales ($)')
    save_chart(fig1, 'sales_trend.png')
    print("✓ Sales trend chart saved")

    # Multi-chart dashboard
    config = [
        {'chart_type': 'line', 'x': 'Date', 'y': 'Sales', 'title': 'Sales Over Time'},
        {'chart_type': 'line', 'x': 'Date', 'y': 'Revenue', 'title': 'Revenue Over Time'},
        {'chart_type': 'scatter', 'x': 'Sales', 'y': 'Revenue', 'title': 'Sales vs Revenue'},
        {'chart_type': 'histogram', 'y': 'Customers', 'title': 'Customer Distribution', 'bins': 20}
    ]
    fig2 = create_multi_chart(sample_df, config, suptitle='Business Dashboard')
    save_chart(fig2, 'dashboard.png')
    print("✓ Dashboard saved")

    print("\nCharts saved successfully!")
