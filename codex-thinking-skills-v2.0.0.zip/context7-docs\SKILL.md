---
name: context7-docs
description: Fetch up-to-date library and framework documentation using Context7 API. Use when Claude needs current documentation for any library, framework, or SDK to avoid hallucinated or outdated APIs. Triggers on requests like "show me Next.js 15 docs", "how to use React Query", "get Terraform AWS provider docs", or any coding question where current documentation would help. Works with 2000+ libraries including Next.js, React, Vue, Tailwind, Prisma, AWS SDK, and more.
---

# Context7 Documentation Fetcher

Fetch up-to-date, version-specific documentation directly from official sources using the Context7 API.

## When to Use

- User asks about a library/framework feature
- Generating code that uses external libraries
- User explicitly says "use context7" or "get docs for X"
- Answering questions where training data might be outdated
- User asks about newer library versions (e.g., Next.js 15, React 19)

## Workflow

### Step 1: Resolve Library ID

First, find the Context7-compatible library ID:

```bash
python3 scripts/context7_fetch.py search "library-name"
```

Example:
```bash
python3 scripts/context7_fetch.py search "nextjs"
```

Output shows available libraries with their IDs (format: `/org/project`).

### Step 2: Fetch Documentation

Once you have the library ID, fetch docs:

```bash
python3 scripts/context7_fetch.py docs "/vercel/next.js" --topic "routing" --tokens 5000
```

Parameters:
- `library_id`: Required. Format `/org/project` or `/org/project/version`
- `--topic`: Optional. Focus on specific topic (e.g., "hooks", "routing", "middleware")
- `--tokens`: Optional. Max tokens to retrieve (default: 5000, min: 1000)

## Quick Examples

```bash
# Search for a library
python3 scripts/context7_fetch.py search "react query"

# Get general docs
python3 scripts/context7_fetch.py docs "/tanstack/query"

# Get topic-specific docs
python3 scripts/context7_fetch.py docs "/tailwindlabs/tailwindcss" --topic "flexbox"

# Get more context for complex topics
python3 scripts/context7_fetch.py docs "/prisma/prisma" --topic "relations" --tokens 10000
```

## Environment Setup

Set `CONTEXT7_API_KEY` environment variable for authenticated requests (higher rate limits):

```bash
export CONTEXT7_API_KEY="your-api-key"
```

API keys available at: https://context7.com/dashboard

Without an API key, the skill uses the public API with lower rate limits.

## Library ID Format

| Format | Example | Description |
|--------|---------|-------------|
| `/org/project` | `/vercel/next.js` | Latest/main version |
| `/org/project/version` | `/vercel/next.js/v14.3.0` | Specific version |

## Popular Libraries

Quick reference for common library IDs:

- Next.js: `/vercel/next.js`
- React: `/facebook/react`
- Vue: `/vuejs/vue`
- Tailwind CSS: `/tailwindlabs/tailwindcss`
- Prisma: `/prisma/prisma`
- React Query: `/tanstack/query`
- Zod: `/colinhacks/zod`
- tRPC: `/trpc/trpc`

For other libraries, always use the search command first.

## Error Handling

- "Library not found": Run search to find correct library ID
- "Documentation not finalized": Library is being indexed, try again later
- Rate limiting: Add API key for higher limits

## See Also

- [API Reference](references/api_reference.md): Full API documentation
- [Troubleshooting](references/troubleshooting.md): Common issues and solutions
