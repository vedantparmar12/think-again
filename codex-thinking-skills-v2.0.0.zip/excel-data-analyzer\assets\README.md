# Sample Data and Templates

This folder contains sample data files and templates you can use to practice with the Excel Data Analyzer skill.

## Sample Files

### sample_sales_data.csv
Sample sales transaction data with the following columns:
- **Date**: Transaction date
- **Region**: Geographic region (East, West, North, South)
- **Product**: Product name
- **Category**: Product category
- **Sales**: Sales amount in dollars
- **Quantity**: Number of units sold
- **CustomerID**: Customer identifier

**Use this for**:
- Creating pivot tables by region and product
- Time series analysis
- Sales trend visualization
- Customer analysis
- Aggregation practice

## Example Usage with Sample Data

### Quick Pivot Analysis

```python
import sys
sys.path.append('C:/Users/vedan/.codex/skills/excel-data-analyzer/scripts')
from data_operations import read_file, create_pivot
from excel_utils import save_to_excel

# Load sample data
df = read_file('sample_sales_data.csv')

# Create pivot table: Total sales by Region and Product
pivot = create_pivot(
    df,
    index='Region',
    columns='Product',
    values='Sales',
    aggfunc='sum',
    margins=True
)

print(pivot)

# Save to Excel
save_to_excel(
    {'Data': df, 'Pivot': pivot},
    'sample_analysis.xlsx'
)
```

### Visualization Example

```python
from visualization import create_chart, save_chart

# Bar chart: Total sales by region
fig = create_chart(
    df.groupby('Region')['Sales'].sum().reset_index(),
    chart_type='bar',
    x='Region',
    y='Sales',
    title='Total Sales by Region',
    color='steelblue'
)
save_chart(fig, 'sales_by_region.png')
```

### Time Series Example

```python
from visualization import create_time_series_plot
import pandas as pd

# Convert date and aggregate by date
df['Date'] = pd.to_datetime(df['Date'])
daily_sales = df.groupby('Date')['Sales'].sum().reset_index()

# Create time series plot
fig = create_time_series_plot(
    daily_sales,
    date_column='Date',
    value_columns='Sales',
    title='Daily Sales Trend',
    rolling_window=7
)
save_chart(fig, 'sales_trend.png')
```

## Creating Your Own Test Data

You can modify the sample data or create your own test datasets to practice different scenarios:

```python
import pandas as pd
import numpy as np

# Create custom sample data
np.random.seed(42)
dates = pd.date_range('2024-01-01', periods=100, freq='D')

custom_data = pd.DataFrame({
    'Date': dates,
    'Product': np.random.choice(['A', 'B', 'C'], 100),
    'Sales': np.random.randint(500, 3000, 100),
    'Region': np.random.choice(['North', 'South', 'East', 'West'], 100)
})

custom_data.to_csv('my_test_data.csv', index=False)
```

## Practice Exercises

Try these exercises with the sample data:

1. **Pivot Practice**: Create a pivot table showing average sales by Category and Region
2. **Filtering**: Filter to show only Electronics category and sales > $1500
3. **Aggregation**: Calculate total sales and quantity by month
4. **Visualization**: Create a pie chart showing sales distribution by product
5. **Multi-chart**: Create a dashboard with 4 different views of the data
6. **Time Series**: Plot sales trends with a 5-day moving average
7. **Merging**: Create a second file with customer information and merge with sales data

## Tips

- Start with small datasets to understand operations
- Experiment with different aggregation functions (sum, mean, count, min, max)
- Try different chart types for the same data
- Practice combining multiple operations in a workflow
- Save your practice scripts for future reference
