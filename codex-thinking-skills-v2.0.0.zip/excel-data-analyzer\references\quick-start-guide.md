# Excel Data Analyzer - Quick Start Guide

## Overview

The Excel Data Analyzer skill enables you to perform comprehensive data analysis operations on CSV and Excel files, including:

- Reading and writing files
- Data transformation and cleaning
- Pivot tables and aggregations
- Merging and joining datasets
- Creating visualizations and charts
- Generating formatted reports

## Prerequisites

Ensure you have the required Python libraries installed:

```bash
pip install pandas openpyxl matplotlib seaborn numpy xlsxwriter
```

## Basic Usage Examples

### 1. Reading Files

```python
# Read a CSV file
import sys
sys.path.append('C:/Users/vedan/.codex/skills/excel-data-analyzer/scripts')
from data_operations import read_file

df = read_file('data.csv')
print(df.head())

# Read an Excel file (specific sheet)
df = read_file('report.xlsx', sheet_name='Sales')

# Read all sheets from Excel
dfs = read_file('report.xlsx', sheet_name=None)
```

### 2. Creating Pivot Tables

```python
from data_operations import create_pivot

# Simple pivot: Total sales by region
pivot = create_pivot(
    df,
    index='Region',
    values='Sales',
    aggfunc='sum'
)

# Multi-dimensional pivot: Sales by region and product
pivot = create_pivot(
    df,
    index='Region',
    columns='Product',
    values='Sales',
    aggfunc='sum',
    margins=True  # Add totals
)
```

### 3. Merging Data

```python
from data_operations import merge_sheets

# Merge two Excel files on Customer ID
merged = merge_sheets(
    'customers.xlsx',
    'orders.xlsx',
    on='CustomerID',
    how='left'
)

# Merge with different column names
merged = merge_sheets(
    df1,
    df2,
    left_on='ID',
    right_on='CustomerID',
    how='inner'
)
```

### 4. Data Cleaning

```python
from data_operations import clean_data

# Basic cleaning
clean_df = clean_data(df, strategy='basic')

# Aggressive cleaning (fills missing values)
clean_df = clean_data(df, strategy='aggressive')

# Custom cleaning
clean_df = clean_data(
    df,
    strategy='custom',
    custom_config={
        'drop_na': False,
        'fill_value': 0,
        'drop_columns': ['Temp', 'Notes']
    }
)
```

### 5. Creating Charts

```python
from visualization import create_chart, save_chart

# Line chart
fig = create_chart(
    df,
    chart_type='line',
    x='Date',
    y='Sales',
    title='Sales Trend Over Time'
)
save_chart(fig, 'sales_trend.png')

# Bar chart
fig = create_chart(
    df,
    chart_type='bar',
    x='Product',
    y='Revenue',
    title='Revenue by Product',
    color='steelblue'
)
save_chart(fig, 'revenue_by_product.png')

# Multiple lines
fig = create_chart(
    df,
    chart_type='line',
    x='Month',
    y=['Sales', 'Revenue', 'Profit'],
    title='Business Metrics'
)
save_chart(fig, 'metrics.png')
```

### 6. Saving to Excel with Formatting

```python
from excel_utils import save_to_excel

# Single sheet
save_to_excel(df, 'output.xlsx', sheet_names='Sales')

# Multiple sheets
data = {
    'Sales': sales_df,
    'Returns': returns_df,
    'Summary': summary_df
}
save_to_excel(data, 'report.xlsx', auto_format=True)
```

## Common Workflows

### Workflow 1: Monthly Sales Report

```python
# 1. Read data
df = read_file('monthly_sales.xlsx')

# 2. Clean data
df = clean_data(df, strategy='basic')

# 3. Create pivot table
pivot = create_pivot(
    df,
    index='Region',
    columns='Product',
    values='Sales',
    aggfunc='sum',
    margins=True
)

# 4. Create visualization
fig = create_chart(
    df,
    chart_type='bar',
    x='Region',
    y='Sales',
    title='Sales by Region'
)
save_chart(fig, 'sales_by_region.png')

# 5. Save report
save_to_excel(
    {'Data': df, 'Pivot': pivot},
    'monthly_report.xlsx',
    auto_format=True
)
```

### Workflow 2: Merge and Analyze

```python
# 1. Merge multiple sources
merged = merge_sheets(
    'customers.xlsx',
    'transactions.xlsx',
    on='CustomerID',
    how='left'
)

# 2. Calculate aggregates
from data_operations import aggregate_data

summary = aggregate_data(
    merged,
    group_by='CustomerID',
    agg_config={
        'TransactionAmount': ['sum', 'mean', 'count']
    }
)

# 3. Create dashboard
from visualization import create_multi_chart

charts_config = [
    {'chart_type': 'bar', 'x': 'CustomerID', 'y': 'TransactionAmount_sum',
     'title': 'Total Spending'},
    {'chart_type': 'histogram', 'y': 'TransactionAmount_mean',
     'title': 'Average Transaction Distribution'}
]

fig = create_multi_chart(summary, charts_config, suptitle='Customer Analysis')
save_chart(fig, 'customer_dashboard.png')

# 4. Save results
save_to_excel(summary, 'customer_analysis.xlsx')
```

### Workflow 3: Time Series Analysis

```python
from visualization import create_time_series_plot

# 1. Read time series data
df = read_file('daily_sales.csv')
df['Date'] = pd.to_datetime(df['Date'])

# 2. Create time series plot with moving average
fig = create_time_series_plot(
    df,
    date_column='Date',
    value_columns=['Sales', 'Revenue'],
    title='Sales Trend with 7-Day Moving Average',
    rolling_window=7
)
save_chart(fig, 'sales_trend.png')

# 3. Aggregate by month
df['Month'] = df['Date'].dt.to_period('M')
monthly = aggregate_data(
    df,
    group_by='Month',
    agg_config={'Sales': 'sum', 'Revenue': 'sum'}
)

# 4. Save monthly summary
save_to_excel(monthly, 'monthly_summary.xlsx')
```

## Tips and Best Practices

1. **Always preview data first**: Use `df.head()` to examine data structure
2. **Check data types**: Use `df.dtypes` to verify column types
3. **Handle missing values**: Decide strategy based on your analysis needs
4. **Validate merges**: Check row counts before and after merging
5. **Use descriptive names**: Name output files clearly with dates/timestamps
6. **Test with small samples**: For large files, test operations on a subset first
7. **Back up original data**: Always create new files, don't overwrite originals

## Troubleshooting

### File Not Found
- Verify the file path is correct
- Use absolute paths or ensure working directory is correct
- Check file extension matches actual format

### Memory Issues
- For large files, read in chunks:
  ```python
  chunks = pd.read_csv('large_file.csv', chunksize=10000)
  for chunk in chunks:
      process(chunk)
  ```

### Merge Produces Wrong Results
- Check join keys for duplicates
- Verify column names match exactly
- Use `validate` parameter to check merge type

### Charts Not Displaying
- If running in script, use `save_chart()` instead of `plt.show()`
- Check that column names are correct
- Ensure data types are numeric for numeric plots

## Next Steps

- Explore the main `SKILL.md` for comprehensive feature list
- Check `examples.md` for more complex scenarios
- Review the Python scripts in `scripts/` folder for implementation details
- Try the sample data in `assets/` folder to practice

## Support

For issues or questions about this skill:
1. Review the documentation in the `references/` folder
2. Check the example scripts in `scripts/`
3. Examine the sample data and templates in `assets/`
