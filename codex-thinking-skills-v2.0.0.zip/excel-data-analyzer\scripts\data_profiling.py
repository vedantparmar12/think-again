"""
Data Profiling and Quality Module for Excel/CSV Analysis
Provides data quality assessment and profiling functions
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Any
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')


def profile_dataset(df: pd.DataFrame, sample_rows: int = 5) -> Dict:
    """
    Generate comprehensive profile of a dataset.

    Args:
        df: DataFrame to profile
        sample_rows: Number of sample rows to include

    Returns:
        Dictionary with profiling information
    """
    profile = {
        'overview': {
            'rows': len(df),
            'columns': len(df.columns),
            'total_cells': df.size,
            'memory_usage_mb': df.memory_usage(deep=True).sum() / 1024 / 1024,
            'duplicated_rows': df.duplicated().sum(),
            'duplicated_rows_pct': (df.duplicated().sum() / len(df)) * 100
        },
        'columns': {},
        'sample_data': df.head(sample_rows).to_dict('records'),
        'data_types': df.dtypes.astype(str).to_dict()
    }

    # Profile each column
    for col in df.columns:
        profile['columns'][col] = profile_column(df, col)

    return profile


def profile_column(df: pd.DataFrame, column: str) -> Dict:
    """
    Generate detailed profile for a single column.

    Args:
        df: DataFrame
        column: Column name

    Returns:
        Dictionary with column profile
    """
    col_data = df[column]
    total_count = len(col_data)
    missing_count = col_data.isna().sum()
    valid_count = total_count - missing_count

    profile = {
        'type': str(col_data.dtype),
        'missing_count': int(missing_count),
        'missing_percentage': float((missing_count / total_count) * 100),
        'valid_count': int(valid_count),
        'unique_count': int(col_data.nunique()),
        'unique_percentage': float((col_data.nunique() / valid_count) * 100) if valid_count > 0 else 0
    }

    # Numeric columns
    if pd.api.types.is_numeric_dtype(col_data):
        valid_data = col_data.dropna()
        if len(valid_data) > 0:
            profile.update({
                'mean': float(valid_data.mean()),
                'median': float(valid_data.median()),
                'std': float(valid_data.std()),
                'min': float(valid_data.min()),
                'max': float(valid_data.max()),
                'zeros_count': int((valid_data == 0).sum()),
                'negative_count': int((valid_data < 0).sum()),
                'positive_count': int((valid_data > 0).sum())
            })

    # String columns
    elif pd.api.types.is_string_dtype(col_data) or col_data.dtype == 'object':
        valid_data = col_data.dropna()
        if len(valid_data) > 0:
            lengths = valid_data.astype(str).str.len()
            profile.update({
                'min_length': int(lengths.min()),
                'max_length': int(lengths.max()),
                'avg_length': float(lengths.mean()),
                'empty_strings': int((valid_data == '').sum()),
                'whitespace_only': int(valid_data.astype(str).str.strip().eq('').sum())
            })

    # Datetime columns
    elif pd.api.types.is_datetime64_any_dtype(col_data):
        valid_data = col_data.dropna()
        if len(valid_data) > 0:
            profile.update({
                'min_date': str(valid_data.min()),
                'max_date': str(valid_data.max()),
                'date_range_days': int((valid_data.max() - valid_data.min()).days)
            })

    # Top values
    top_values = col_data.value_counts().head(10)
    profile['top_values'] = {
        str(k): int(v) for k, v in top_values.items()
    }

    return profile


def data_quality_score(df: pd.DataFrame) -> Dict:
    """
    Calculate overall data quality score.

    Args:
        df: DataFrame to assess

    Returns:
        Dictionary with quality metrics and score
    """
    total_cells = df.size
    missing_cells = df.isna().sum().sum()
    duplicate_rows = df.duplicated().sum()

    # Quality metrics
    completeness = ((total_cells - missing_cells) / total_cells) * 100
    uniqueness = ((len(df) - duplicate_rows) / len(df)) * 100

    # Check for consistency (columns with mixed types)
    consistency_issues = 0
    for col in df.columns:
        if df[col].dtype == 'object':
            # Check if column has mixed numeric and string values
            non_null = df[col].dropna()
            if len(non_null) > 0:
                try:
                    pd.to_numeric(non_null)
                    consistency_issues += 1  # Column could be numeric but stored as object
                except:
                    pass

    consistency = ((len(df.columns) - consistency_issues) / len(df.columns)) * 100

    # Overall quality score (weighted average)
    overall_score = (
        completeness * 0.4 +
        uniqueness * 0.3 +
        consistency * 0.3
    )

    return {
        'overall_score': round(overall_score, 2),
        'completeness': round(completeness, 2),
        'uniqueness': round(uniqueness, 2),
        'consistency': round(consistency, 2),
        'grade': get_quality_grade(overall_score),
        'issues': {
            'missing_cells': int(missing_cells),
            'missing_percentage': round((missing_cells / total_cells) * 100, 2),
            'duplicate_rows': int(duplicate_rows),
            'duplicate_percentage': round((duplicate_rows / len(df)) * 100, 2),
            'consistency_issues': consistency_issues
        }
    }


def get_quality_grade(score: float) -> str:
    """Get letter grade for quality score."""
    if score >= 90:
        return 'A (Excellent)'
    elif score >= 80:
        return 'B (Good)'
    elif score >= 70:
        return 'C (Fair)'
    elif score >= 60:
        return 'D (Poor)'
    else:
        return 'F (Critical)'


def detect_data_issues(df: pd.DataFrame) -> Dict:
    """
    Detect various data quality issues.

    Args:
        df: DataFrame to check

    Returns:
        Dictionary with detected issues
    """
    issues = {
        'missing_values': {},
        'duplicates': {},
        'outliers': {},
        'data_type_issues': {},
        'inconsistencies': {}
    }

    # Missing values per column
    for col in df.columns:
        missing = df[col].isna().sum()
        if missing > 0:
            issues['missing_values'][col] = {
                'count': int(missing),
                'percentage': round((missing / len(df)) * 100, 2)
            }

    # Duplicate rows
    duplicates = df[df.duplicated(keep=False)]
    if len(duplicates) > 0:
        issues['duplicates'] = {
            'count': len(duplicates),
            'percentage': round((len(duplicates) / len(df)) * 100, 2),
            'sample_indices': duplicates.index[:5].tolist()
        }

    # Outliers in numeric columns
    for col in df.select_dtypes(include=[np.number]).columns:
        from statistical_analysis import outlier_detection
        outlier_info = outlier_detection(df[col])
        if outlier_info['n_outliers'] > 0:
            issues['outliers'][col] = {
                'count': outlier_info['n_outliers'],
                'percentage': round(outlier_info['outlier_percentage'], 2),
                'bounds': (outlier_info['lower_bound'], outlier_info['upper_bound'])
            }

    # Data type issues
    for col in df.columns:
        if df[col].dtype == 'object':
            # Check if should be numeric
            non_null = df[col].dropna()
            if len(non_null) > 0:
                numeric_count = pd.to_numeric(non_null, errors='coerce').notna().sum()
                if numeric_count / len(non_null) > 0.8:  # 80% could be numeric
                    issues['data_type_issues'][col] = 'Should be numeric'

    # Inconsistencies (e.g., mixed case, whitespace)
    for col in df.select_dtypes(include=['object']).columns:
        non_null = df[col].dropna()
        if len(non_null) > 0:
            # Check for leading/trailing whitespace
            with_whitespace = non_null.astype(str).str.strip().ne(non_null.astype(str)).sum()
            if with_whitespace > 0:
                if col not in issues['inconsistencies']:
                    issues['inconsistencies'][col] = []
                issues['inconsistencies'][col].append(f'{with_whitespace} values with whitespace')

            # Check for mixed case
            strings = non_null.astype(str)
            lower_count = strings.str.islower().sum()
            upper_count = strings.str.isupper().sum()
            if lower_count > 0 and upper_count > 0:
                if col not in issues['inconsistencies']:
                    issues['inconsistencies'][col] = []
                issues['inconsistencies'][col].append('Mixed case values')

    return issues


def generate_data_quality_report(df: pd.DataFrame) -> str:
    """
    Generate human-readable data quality report.

    Args:
        df: DataFrame to analyze

    Returns:
        Formatted report string
    """
    profile = profile_dataset(df, sample_rows=0)
    quality = data_quality_score(df)
    issues = detect_data_issues(df)

    report = []
    report.append("=" * 70)
    report.append("DATA QUALITY REPORT")
    report.append("=" * 70)
    report.append("")

    # Overview
    report.append("DATASET OVERVIEW")
    report.append("-" * 70)
    report.append(f"Rows: {profile['overview']['rows']:,}")
    report.append(f"Columns: {profile['overview']['columns']:,}")
    report.append(f"Memory Usage: {profile['overview']['memory_usage_mb']:.2f} MB")
    report.append("")

    # Quality Score
    report.append("OVERALL QUALITY SCORE")
    report.append("-" * 70)
    report.append(f"Score: {quality['overall_score']}/100 - {quality['grade']}")
    report.append(f"  Completeness: {quality['completeness']:.1f}%")
    report.append(f"  Uniqueness: {quality['uniqueness']:.1f}%")
    report.append(f"  Consistency: {quality['consistency']:.1f}%")
    report.append("")

    # Issues Summary
    report.append("ISSUES SUMMARY")
    report.append("-" * 70)
    report.append(f"Missing Cells: {quality['issues']['missing_cells']:,} ({quality['issues']['missing_percentage']:.1f}%)")
    report.append(f"Duplicate Rows: {quality['issues']['duplicate_rows']:,} ({quality['issues']['duplicate_percentage']:.1f}%)")
    report.append(f"Consistency Issues: {quality['issues']['consistency_issues']}")
    report.append("")

    # Columns with issues
    if issues['missing_values']:
        report.append("COLUMNS WITH MISSING VALUES")
        report.append("-" * 70)
        for col, info in issues['missing_values'].items():
            report.append(f"  {col}: {info['count']} missing ({info['percentage']:.1f}%)")
        report.append("")

    if issues['outliers']:
        report.append("COLUMNS WITH OUTLIERS")
        report.append("-" * 70)
        for col, info in issues['outliers'].items():
            report.append(f"  {col}: {info['count']} outliers ({info['percentage']:.1f}%)")
        report.append("")

    if issues['data_type_issues']:
        report.append("DATA TYPE ISSUES")
        report.append("-" * 70)
        for col, issue in issues['data_type_issues'].items():
            report.append(f"  {col}: {issue}")
        report.append("")

    if issues['inconsistencies']:
        report.append("INCONSISTENCIES")
        report.append("-" * 70)
        for col, issue_list in issues['inconsistencies'].items():
            report.append(f"  {col}:")
            for issue in issue_list:
                report.append(f"    - {issue}")
        report.append("")

    report.append("=" * 70)

    return "\n".join(report)


def recommend_fixes(df: pd.DataFrame) -> List[Dict]:
    """
    Recommend fixes for data quality issues.

    Args:
        df: DataFrame to analyze

    Returns:
        List of recommended fixes
    """
    recommendations = []
    issues = detect_data_issues(df)

    # Missing values
    for col, info in issues['missing_values'].items():
        if info['percentage'] > 50:
            recommendations.append({
                'column': col,
                'issue': 'High missing values',
                'recommendation': 'Consider dropping this column',
                'action': f"df.drop(columns=['{col}'])"
            })
        elif info['percentage'] > 5:
            if pd.api.types.is_numeric_dtype(df[col]):
                recommendations.append({
                    'column': col,
                    'issue': f"{info['percentage']:.1f}% missing values",
                    'recommendation': 'Fill with median',
                    'action': f"df['{col}'].fillna(df['{col}'].median(), inplace=True)"
                })
            else:
                recommendations.append({
                    'column': col,
                    'issue': f"{info['percentage']:.1f}% missing values",
                    'recommendation': 'Fill with mode or "Unknown"',
                    'action': f"df['{col}'].fillna('Unknown', inplace=True)"
                })

    # Duplicates
    if 'count' in issues['duplicates']:
        recommendations.append({
            'column': 'All',
            'issue': f"{issues['duplicates']['count']} duplicate rows",
            'recommendation': 'Remove duplicate rows',
            'action': "df.drop_duplicates(inplace=True)"
        })

    # Data type issues
    for col, issue in issues['data_type_issues'].items():
        recommendations.append({
            'column': col,
            'issue': issue,
            'recommendation': 'Convert to numeric',
            'action': f"df['{col}'] = pd.to_numeric(df['{col}'], errors='coerce')"
        })

    # Inconsistencies
    for col, issue_list in issues['inconsistencies'].items():
        if 'whitespace' in str(issue_list):
            recommendations.append({
                'column': col,
                'issue': 'Whitespace in values',
                'recommendation': 'Strip whitespace',
                'action': f"df['{col}'] = df['{col}'].str.strip()"
            })
        if 'Mixed case' in str(issue_list):
            recommendations.append({
                'column': col,
                'issue': 'Mixed case',
                'recommendation': 'Standardize to lowercase',
                'action': f"df['{col}'] = df['{col}'].str.lower()"
            })

    return recommendations


def compare_datasets(df1: pd.DataFrame, df2: pd.DataFrame) -> Dict:
    """
    Compare two datasets and identify differences.

    Args:
        df1: First DataFrame
        df2: Second DataFrame

    Returns:
        Dictionary with comparison results
    """
    comparison = {
        'shape_comparison': {
            'df1_shape': df1.shape,
            'df2_shape': df2.shape,
            'same_shape': df1.shape == df2.shape
        },
        'column_comparison': {
            'df1_only': list(set(df1.columns) - set(df2.columns)),
            'df2_only': list(set(df2.columns) - set(df1.columns)),
            'common': list(set(df1.columns) & set(df2.columns))
        },
        'data_type_differences': {},
        'value_differences': {}
    }

    # Compare data types for common columns
    for col in comparison['column_comparison']['common']:
        if df1[col].dtype != df2[col].dtype:
            comparison['data_type_differences'][col] = {
                'df1': str(df1[col].dtype),
                'df2': str(df2[col].dtype)
            }

    # Compare values for common columns (if same shape)
    if df1.shape == df2.shape:
        for col in comparison['column_comparison']['common']:
            differences = (df1[col] != df2[col]).sum()
            if differences > 0:
                comparison['value_differences'][col] = {
                    'different_values': int(differences),
                    'percentage': round((differences / len(df1)) * 100, 2)
                }

    return comparison


def validate_against_schema(
    df: pd.DataFrame,
    schema: Dict[str, Dict[str, Any]]
) -> Dict:
    """
    Validate DataFrame against a schema.

    Args:
        df: DataFrame to validate
        schema: Schema dict with column definitions
                Example: {'col1': {'type': 'int', 'min': 0, 'max': 100, 'required': True}}

    Returns:
        Dictionary with validation results
    """
    results = {
        'valid': True,
        'errors': [],
        'warnings': []
    }

    for col, rules in schema.items():
        # Check if column exists
        if col not in df.columns:
            if rules.get('required', False):
                results['valid'] = False
                results['errors'].append(f"Required column '{col}' is missing")
            else:
                results['warnings'].append(f"Optional column '{col}' is missing")
            continue

        # Check data type
        if 'type' in rules:
            expected_type = rules['type']
            actual_type = str(df[col].dtype)

            if expected_type == 'int' and not pd.api.types.is_integer_dtype(df[col]):
                results['errors'].append(f"Column '{col}' should be int, got {actual_type}")
                results['valid'] = False
            elif expected_type == 'float' and not pd.api.types.is_float_dtype(df[col]):
                results['errors'].append(f"Column '{col}' should be float, got {actual_type}")
                results['valid'] = False
            elif expected_type == 'string' and not pd.api.types.is_string_dtype(df[col]):
                results['errors'].append(f"Column '{col}' should be string, got {actual_type}")
                results['valid'] = False

        # Check numeric constraints
        if pd.api.types.is_numeric_dtype(df[col]):
            if 'min' in rules and df[col].min() < rules['min']:
                results['warnings'].append(f"Column '{col}' has values below minimum {rules['min']}")

            if 'max' in rules and df[col].max() > rules['max']:
                results['warnings'].append(f"Column '{col}' has values above maximum {rules['max']}")

        # Check for null values
        if rules.get('required', False) and df[col].isna().any():
            results['errors'].append(f"Column '{col}' has null values but is required")
            results['valid'] = False

    return results


if __name__ == "__main__":
    # Example usage
    print("Data Profiling Module - Example Usage")
    print("=" * 70)

    # Create sample data with quality issues
    np.random.seed(42)
    df = pd.DataFrame({
        'ID': range(1, 101),
        'Name': ['Customer ' + str(i) if i % 10 != 0 else None for i in range(1, 101)],
        'Sales': [np.random.randint(100, 1000) if i % 15 != 0 else None for i in range(100)],
        'Region': np.random.choice(['North', 'South', 'east', 'WEST', ' North '], 100),
        'Amount': ['100' if i % 5 == 0 else np.random.randint(50, 500) for i in range(100)]
    })

    # Add some duplicates
    df = pd.concat([df, df.iloc[:5]], ignore_index=True)

    # Generate quality report
    print(generate_data_quality_report(df))

    # Get recommendations
    print("\nRECOMMENDED FIXES")
    print("-" * 70)
    recommendations = recommend_fixes(df)
    for i, rec in enumerate(recommendations, 1):
        print(f"{i}. {rec['column']}: {rec['issue']}")
        print(f"   Fix: {rec['recommendation']}")
        print(f"   Code: {rec['action']}")
        print()
