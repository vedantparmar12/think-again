---
plan_id: YYYY-MM-DD-feature-name
created: YYYY-MM-DDTHH:MM:SSZ
status: draft
model:
milestone_count:
---

# ExecPlan: [Feature Name]

## Purpose

[Clear, concise statement of what needs to be built and why]

## Context

**Current Architecture:**
-

**Key Dependencies:**
-

**Constraints:**
-

## Approach

[High-level strategy for implementation]

**Why this approach:**
-

## Milestones

### Milestone 1: [Name]

**Goal:**

**Implementation:**
-

**Verification:**
- [ ]

**Files Affected:**
-

**Estimated Effort:**

**Dependencies:**

---

## Progress

- [ ] Milestone 1:

## Decision Log

### Decision 1: [Title]
- **Context:**
- **Options Considered:**
  1.
  2.
- **Decision:**
- **Rationale:**

## Risks & Mitigations

| Risk | Impact | Probability | Mitigation |
|------|--------|-------------|------------|
|      |        |             |            |

## Surprises & Discoveries

-

## Next Steps

1.

## Estimated Total Effort

[Total time estimate based on all milestones]
