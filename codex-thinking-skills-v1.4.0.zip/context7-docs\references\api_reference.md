# Context7 API Reference

## Public REST API Endpoints

### Search Libraries

```
GET https://api.context7.com/v1/search?q={query}
```

**Parameters:**
- `q` (required): Search query string

**Response:**
```json
{
  "results": [
    {
      "id": "/vercel/next.js",
      "name": "Next.js",
      "codeSnippetCount": 1500,
      "sourceReputation": "official",
      "versions": ["v15.0.0", "v14.2.0", "v14.1.0"]
    }
  ]
}
```

### Get Documentation

```
GET https://api.context7.com/v1/docs/{library_id}?tokens={n}&topic={topic}
```

**Parameters:**
- `library_id` (required): Path parameter, e.g., `/vercel/next.js`
- `tokens` (optional): Max tokens to return (default: 5000, min: 1000)
- `topic` (optional): Focus documentation on specific topic

**Response:**
```json
{
  "content": "# Next.js Documentation\n\n...",
  "library": "/vercel/next.js",
  "version": "latest"
}
```

## Authentication

Optional but recommended for higher rate limits.

**Header Options (any of these work):**
- `Authorization: Bearer YOUR_API_KEY`
- `Context7-API-Key: YOUR_API_KEY`
- `X-API-Key: YOUR_API_KEY`

## Rate Limits

| Plan | Requests/minute | Requests/day |
|------|-----------------|--------------|
| Free | 10 | 100 |
| Pro | 60 | 5000 |
| Team | 200 | Unlimited |

## Error Codes

| Code | Meaning | Solution |
|------|---------|----------|
| 400 | Bad request | Check library ID format |
| 404 | Library not found | Use search to find correct ID |
| 429 | Rate limited | Wait or add API key |
| 500 | Server error | Retry after a moment |

## MCP Protocol

If using via MCP server instead of REST API:

**Tools Available:**
1. `resolve-library-id` - Search for libraries
2. `get-library-docs` - Fetch documentation

**MCP Server URL:**
```
https://mcp.context7.com/mcp
```

**Stdio Mode:**
```bash
npx -y @upstash/context7-mcp
```
