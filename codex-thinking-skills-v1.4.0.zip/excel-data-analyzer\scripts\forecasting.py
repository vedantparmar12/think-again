"""
Forecasting and Time Series Module for Excel/CSV Analysis
Provides time series analysis and forecasting capabilities
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


def moving_average(
    data: pd.Series,
    window: int,
    center: bool = False
) -> pd.Series:
    """
    Calculate moving average.

    Args:
        data: Time series data
        window: Window size
        center: Center the window

    Returns:
        Moving average series
    """
    return data.rolling(window=window, center=center).mean()


def exponential_smoothing(
    data: pd.Series,
    alpha: float = 0.3
) -> pd.Series:
    """
    Apply exponential smoothing.

    Args:
        data: Time series data
        alpha: Smoothing parameter (0-1)

    Returns:
        Smoothed series
    """
    return data.ewm(alpha=alpha, adjust=False).mean()


def decompose_time_series(
    data: pd.Series,
    period: int,
    model: str = 'additive'
) -> Dict:
    """
    Decompose time series into trend, seasonal, and residual components.

    Args:
        data: Time series data
        period: Seasonal period
        model: 'additive' or 'multiplicative'

    Returns:
        Dictionary with decomposition components
    """
    from statsmodels.tsa.seasonal import seasonal_decompose

    result = seasonal_decompose(data, model=model, period=period, extrapolate_trend='freq')

    return {
        'observed': result.observed,
        'trend': result.trend,
        'seasonal': result.seasonal,
        'residual': result.resid
    }


def detect_seasonality(
    data: pd.Series,
    max_period: int = 365
) -> Dict:
    """
    Detect seasonality in time series.

    Args:
        data: Time series data
        max_period: Maximum period to check

    Returns:
        Dictionary with seasonality information
    """
    from scipy import signal

    # Remove NaN values
    clean_data = data.dropna()

    # Compute autocorrelation
    autocorr = [clean_data.autocorr(lag=i) for i in range(1, min(max_period, len(clean_data)//2))]

    # Find peaks in autocorrelation
    peaks, properties = signal.find_peaks(autocorr, height=0.3)

    if len(peaks) > 0:
        primary_period = peaks[0] + 1  # +1 because we started from lag=1
        seasonal = True
        strength = autocorr[peaks[0]]
    else:
        primary_period = None
        seasonal = False
        strength = 0

    return {
        'is_seasonal': seasonal,
        'period': primary_period,
        'strength': strength,
        'autocorrelation': autocorr
    }


def calculate_trend(
    df: pd.DataFrame,
    date_col: str,
    value_col: str,
    method: str = 'linear'
) -> Dict:
    """
    Calculate trend in time series.

    Args:
        df: DataFrame with time series data
        date_col: Date column name
        value_col: Value column name
        method: 'linear' or 'polynomial'

    Returns:
        Dictionary with trend information
    """
    # Convert dates to numeric (days since first date)
    df_copy = df.copy()
    df_copy[date_col] = pd.to_datetime(df_copy[date_col])
    df_copy = df_copy.sort_values(date_col)

    first_date = df_copy[date_col].min()
    df_copy['days'] = (df_copy[date_col] - first_date).dt.days

    x = df_copy['days'].values
    y = df_copy[value_col].values

    if method == 'linear':
        # Linear regression
        coeffs = np.polyfit(x, y, 1)
        trend_line = np.poly1d(coeffs)
        predictions = trend_line(x)

        slope = coeffs[0]
        direction = 'Increasing' if slope > 0 else 'Decreasing' if slope < 0 else 'Flat'

    elif method == 'polynomial':
        # Polynomial regression (degree 2)
        coeffs = np.polyfit(x, y, 2)
        trend_line = np.poly1d(coeffs)
        predictions = trend_line(x)

        # Determine direction based on first derivative at the end
        derivative = np.polyder(trend_line)
        slope = derivative(x[-1])
        direction = 'Increasing' if slope > 0 else 'Decreasing' if slope < 0 else 'Flat'

    else:
        raise ValueError(f"Unknown method: {method}")

    # Calculate R-squared
    ss_res = np.sum((y - predictions) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r_squared = 1 - (ss_res / ss_tot)

    return {
        'method': method,
        'coefficients': coeffs.tolist(),
        'direction': direction,
        'slope': slope,
        'r_squared': r_squared,
        'predictions': predictions,
        'equation': str(trend_line)
    }


def simple_forecast(
    data: pd.Series,
    periods: int,
    method: str = 'mean'
) -> pd.Series:
    """
    Generate simple forecast.

    Args:
        data: Historical time series data
        periods: Number of periods to forecast
        method: 'mean', 'last', or 'drift'

    Returns:
        Forecasted series
    """
    if method == 'mean':
        # Forecast using historical mean
        forecast_value = data.mean()
        forecast = pd.Series([forecast_value] * periods)

    elif method == 'last':
        # Forecast using last observed value
        forecast_value = data.iloc[-1]
        forecast = pd.Series([forecast_value] * periods)

    elif method == 'drift':
        # Forecast using drift (linear trend from first to last)
        slope = (data.iloc[-1] - data.iloc[0]) / (len(data) - 1)
        last_value = data.iloc[-1]
        forecast = pd.Series([last_value + slope * (i + 1) for i in range(periods)])

    else:
        raise ValueError(f"Unknown method: {method}")

    # Create index for forecast
    if isinstance(data.index, pd.DatetimeIndex):
        freq = pd.infer_freq(data.index)
        if freq:
            forecast.index = pd.date_range(
                start=data.index[-1] + pd.Timedelta(freq),
                periods=periods,
                freq=freq
            )
    else:
        forecast.index = range(len(data), len(data) + periods)

    return forecast


def moving_average_forecast(
    data: pd.Series,
    window: int,
    periods: int
) -> pd.Series:
    """
    Forecast using moving average.

    Args:
        data: Historical time series data
        window: Moving average window
        periods: Number of periods to forecast

    Returns:
        Forecasted series
    """
    forecast = []
    current_data = data.copy()

    for _ in range(periods):
        # Calculate MA of last 'window' values
        ma_value = current_data.iloc[-window:].mean()
        forecast.append(ma_value)

        # Append forecast to current data for next iteration
        current_data = pd.concat([current_data, pd.Series([ma_value])])

    forecast_series = pd.Series(forecast)

    # Create index for forecast
    if isinstance(data.index, pd.DatetimeIndex):
        freq = pd.infer_freq(data.index)
        if freq:
            forecast_series.index = pd.date_range(
                start=data.index[-1] + pd.Timedelta(freq),
                periods=periods,
                freq=freq
            )

    return forecast_series


def exponential_smoothing_forecast(
    data: pd.Series,
    alpha: float,
    periods: int
) -> pd.Series:
    """
    Forecast using exponential smoothing.

    Args:
        data: Historical time series data
        alpha: Smoothing parameter
        periods: Number of periods to forecast

    Returns:
        Forecasted series
    """
    # Apply exponential smoothing to historical data
    smoothed = exponential_smoothing(data, alpha)

    # Forecast (using last smoothed value)
    forecast_value = smoothed.iloc[-1]
    forecast = pd.Series([forecast_value] * periods)

    # Create index for forecast
    if isinstance(data.index, pd.DatetimeIndex):
        freq = pd.infer_freq(data.index)
        if freq:
            forecast.index = pd.date_range(
                start=data.index[-1] + pd.Timedelta(freq),
                periods=periods,
                freq=freq
            )

    return forecast


def calculate_forecast_accuracy(
    actual: pd.Series,
    predicted: pd.Series
) -> Dict:
    """
    Calculate forecast accuracy metrics.

    Args:
        actual: Actual values
        predicted: Predicted values

    Returns:
        Dictionary with accuracy metrics
    """
    # Align series
    actual, predicted = actual.align(predicted, join='inner')

    # Remove NaN values
    mask = ~(actual.isna() | predicted.isna())
    actual = actual[mask]
    predicted = predicted[mask]

    if len(actual) == 0:
        return {'error': 'No overlapping data points'}

    # Calculate metrics
    errors = actual - predicted
    abs_errors = np.abs(errors)
    pct_errors = np.abs(errors / actual) * 100

    mae = abs_errors.mean()  # Mean Absolute Error
    mse = (errors ** 2).mean()  # Mean Squared Error
    rmse = np.sqrt(mse)  # Root Mean Squared Error
    mape = pct_errors.mean()  # Mean Absolute Percentage Error

    # R-squared
    ss_res = np.sum(errors ** 2)
    ss_tot = np.sum((actual - actual.mean()) ** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0

    return {
        'mae': mae,
        'mse': mse,
        'rmse': rmse,
        'mape': mape,
        'r_squared': r_squared,
        'n_points': len(actual)
    }


def detect_anomalies(
    data: pd.Series,
    method: str = 'iqr',
    threshold: float = 1.5
) -> Dict:
    """
    Detect anomalies in time series.

    Args:
        data: Time series data
        method: 'iqr', 'zscore', or 'isolation_forest'
        threshold: Threshold for anomaly detection

    Returns:
        Dictionary with anomaly information
    """
    clean_data = data.dropna()

    if method == 'iqr':
        Q1 = clean_data.quantile(0.25)
        Q3 = clean_data.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - threshold * IQR
        upper_bound = Q3 + threshold * IQR
        anomalies = (clean_data < lower_bound) | (clean_data > upper_bound)

    elif method == 'zscore':
        from scipy import stats
        z_scores = np.abs(stats.zscore(clean_data))
        anomalies = z_scores > threshold
        lower_bound = clean_data.mean() - threshold * clean_data.std()
        upper_bound = clean_data.mean() + threshold * clean_data.std()

    elif method == 'isolation_forest':
        from sklearn.ensemble import IsolationForest
        model = IsolationForest(contamination=0.1, random_state=42)
        predictions = model.fit_predict(clean_data.values.reshape(-1, 1))
        anomalies = pd.Series(predictions == -1, index=clean_data.index)
        lower_bound = None
        upper_bound = None

    else:
        raise ValueError(f"Unknown method: {method}")

    anomaly_dates = clean_data[anomalies].index.tolist()
    anomaly_values = clean_data[anomalies].tolist()

    return {
        'method': method,
        'n_anomalies': anomalies.sum(),
        'anomaly_percentage': (anomalies.sum() / len(clean_data)) * 100,
        'anomaly_indices': anomaly_dates,
        'anomaly_values': anomaly_values,
        'lower_bound': lower_bound,
        'upper_bound': upper_bound,
        'is_anomaly': anomalies
    }


def calculate_growth_rate(
    df: pd.DataFrame,
    date_col: str,
    value_col: str,
    period: str = 'M'
) -> pd.DataFrame:
    """
    Calculate growth rates over time.

    Args:
        df: DataFrame with time series data
        date_col: Date column name
        value_col: Value column name
        period: Aggregation period ('D', 'W', 'M', 'Q', 'Y')

    Returns:
        DataFrame with growth rates
    """
    df_copy = df.copy()
    df_copy[date_col] = pd.to_datetime(df_copy[date_col])
    df_copy = df_copy.sort_values(date_col)

    # Aggregate by period
    df_copy['period'] = df_copy[date_col].dt.to_period(period)
    aggregated = df_copy.groupby('period')[value_col].sum().reset_index()

    # Calculate growth rates
    aggregated['previous_value'] = aggregated[value_col].shift(1)
    aggregated['absolute_change'] = aggregated[value_col] - aggregated['previous_value']
    aggregated['growth_rate'] = (aggregated['absolute_change'] / aggregated['previous_value'] * 100)

    # Calculate cumulative growth
    aggregated['cumulative_growth'] = ((aggregated[value_col] / aggregated[value_col].iloc[0]) - 1) * 100

    return aggregated


def year_over_year_comparison(
    df: pd.DataFrame,
    date_col: str,
    value_col: str,
    period: str = 'M'
) -> pd.DataFrame:
    """
    Calculate year-over-year comparisons.

    Args:
        df: DataFrame with time series data
        date_col: Date column name
        value_col: Value column name
        period: Comparison period ('M' for month, 'Q' for quarter)

    Returns:
        DataFrame with YoY comparisons
    """
    df_copy = df.copy()
    df_copy[date_col] = pd.to_datetime(df_copy[date_col])

    # Extract year and period
    df_copy['year'] = df_copy[date_col].dt.year
    if period == 'M':
        df_copy['period'] = df_copy[date_col].dt.month
    elif period == 'Q':
        df_copy['period'] = df_copy[date_col].dt.quarter
    else:
        raise ValueError("Period must be 'M' or 'Q'")

    # Aggregate by year and period
    yoy = df_copy.groupby(['year', 'period'])[value_col].sum().reset_index()

    # Pivot to compare years
    yoy_pivot = yoy.pivot(index='period', columns='year', values=value_col)

    # Calculate YoY changes
    for i in range(1, len(yoy_pivot.columns)):
        prev_year = yoy_pivot.columns[i-1]
        curr_year = yoy_pivot.columns[i]
        yoy_pivot[f'YoY_Change_{curr_year}'] = yoy_pivot[curr_year] - yoy_pivot[prev_year]
        yoy_pivot[f'YoY_%_{curr_year}'] = (
            (yoy_pivot[curr_year] - yoy_pivot[prev_year]) / yoy_pivot[prev_year] * 100
        )

    return yoy_pivot.reset_index()


def predict_next_values(
    data: pd.Series,
    method: str = 'auto',
    periods: int = 12,
    **kwargs
) -> Dict:
    """
    Predict next values using best method.

    Args:
        data: Historical time series data
        method: 'auto', 'ma', 'es', 'arima', or 'prophet'
        periods: Number of periods to forecast
        **kwargs: Additional parameters for specific methods

    Returns:
        Dictionary with forecast and metadata
    """
    if method == 'auto':
        # Choose method based on data characteristics
        if len(data) < 20:
            method = 'ma'
        else:
            seasonality = detect_seasonality(data)
            method = 'es' if not seasonality['is_seasonal'] else 'ma'

    if method == 'ma':
        window = kwargs.get('window', min(7, len(data) // 3))
        forecast = moving_average_forecast(data, window, periods)

    elif method == 'es':
        alpha = kwargs.get('alpha', 0.3)
        forecast = exponential_smoothing_forecast(data, alpha, periods)

    elif method == 'arima':
        try:
            from statsmodels.tsa.arima.model import ARIMA
            model = ARIMA(data, order=kwargs.get('order', (1, 1, 1)))
            fitted = model.fit()
            forecast = fitted.forecast(steps=periods)
        except:
            # Fallback to exponential smoothing
            forecast = exponential_smoothing_forecast(data, 0.3, periods)

    elif method == 'prophet':
        try:
            from prophet import Prophet
            df = pd.DataFrame({'ds': data.index, 'y': data.values})
            model = Prophet()
            model.fit(df)
            future = model.make_future_dataframe(periods=periods)
            prediction = model.predict(future)
            forecast = prediction[['ds', 'yhat']].tail(periods).set_index('ds')['yhat']
        except:
            # Fallback to exponential smoothing
            forecast = exponential_smoothing_forecast(data, 0.3, periods)

    else:
        raise ValueError(f"Unknown method: {method}")

    return {
        'method': method,
        'forecast': forecast,
        'periods': periods,
        'last_value': data.iloc[-1],
        'forecast_mean': forecast.mean()
    }


if __name__ == "__main__":
    # Example usage
    print("Forecasting Module - Example Usage")
    print("=" * 70)

    # Create sample time series data
    np.random.seed(42)
    dates = pd.date_range('2023-01-01', periods=365, freq='D')
    trend = np.linspace(100, 200, 365)
    seasonal = 20 * np.sin(np.arange(365) * 2 * np.pi / 7)  # Weekly seasonality
    noise = np.random.normal(0, 5, 365)
    values = trend + seasonal + noise

    ts_data = pd.Series(values, index=dates)

    # Decomposition
    print("\nTIME SERIES DECOMPOSITION")
    print("-" * 70)
    decomp = decompose_time_series(ts_data, period=7)
    print("Components: Observed, Trend, Seasonal, Residual")

    # Detect seasonality
    print("\nSEASONALITY DETECTION")
    print("-" * 70)
    seasonality = detect_seasonality(ts_data, max_period=30)
    print(f"Is Seasonal: {seasonality['is_seasonal']}")
    print(f"Period: {seasonality['period']}")
    print(f"Strength: {seasonality['strength']:.2f}")

    # Trend analysis
    df_trend = pd.DataFrame({'Date': dates, 'Value': values})
    print("\nTREND ANALYSIS")
    print("-" * 70)
    trend_result = calculate_trend(df_trend, 'Date', 'Value')
    print(f"Direction: {trend_result['direction']}")
    print(f"R-squared: {trend_result['r_squared']:.4f}")

    # Simple forecast
    print("\nFORECAST (Next 7 Days)")
    print("-" * 70)
    forecast = predict_next_values(ts_data, method='ma', periods=7, window=7)
    print(f"Method: {forecast['method']}")
    print(f"Forecast mean: {forecast['forecast_mean']:.2f}")

    # Anomaly detection
    print("\nANOMALY DETECTION")
    print("-" * 70)
    anomalies = detect_anomalies(ts_data, method='iqr')
    print(f"Anomalies found: {anomalies['n_anomalies']}")
    print(f"Percentage: {anomalies['anomaly_percentage']:.2f}%")

    print("\nForecasting demonstration complete!")
