"""
Setup Verification Script for Excel Data Analyzer Skill
Run this script to verify all dependencies are properly installed
"""

import sys
from pathlib import Path

def check_dependencies():
    """Check if all required Python libraries are installed"""
    print("Checking Python Dependencies...")
    print("=" * 60)

    dependencies = {
        'pandas': '2.0.0',
        'openpyxl': '3.1.0',
        'matplotlib': '3.7.0',
        'seaborn': '0.12.0',
        'numpy': '1.24.0',
        'xlsxwriter': '3.1.0'
    }

    all_installed = True

    for package, min_version in dependencies.items():
        try:
            module = __import__(package)
            version = getattr(module, '__version__', 'unknown')
            print(f"✓ {package:15s} - version {version}")
        except ImportError:
            print(f"✗ {package:15s} - NOT INSTALLED")
            all_installed = False

    print("=" * 60)

    if all_installed:
        print("✓ All dependencies are installed!")
        return True
    else:
        print("✗ Some dependencies are missing.")
        print("\nInstall missing packages with:")
        print("  pip install -r requirements.txt")
        return False


def check_skill_structure():
    """Verify the skill folder structure is correct"""
    print("\nChecking Skill Structure...")
    print("=" * 60)

    skill_root = Path(__file__).parent.parent

    required_files = [
        'SKILL.md',
        'README.md',
        'requirements.txt',
        'scripts/data_operations.py',
        'scripts/visualization.py',
        'scripts/excel_utils.py',
        'references/quick-start-guide.md',
        'references/examples.md',
        'assets/sample_sales_data.csv',
        'assets/README.md'
    ]

    all_present = True

    for file_path in required_files:
        full_path = skill_root / file_path
        if full_path.exists():
            print(f"✓ {file_path}")
        else:
            print(f"✗ {file_path} - MISSING")
            all_present = False

    print("=" * 60)

    if all_present:
        print("✓ All required files are present!")
        return True
    else:
        print("✗ Some files are missing.")
        return False


def test_basic_functionality():
    """Test basic functionality of the skill modules"""
    print("\nTesting Basic Functionality...")
    print("=" * 60)

    try:
        # Add scripts directory to path
        skill_root = Path(__file__).parent.parent
        sys.path.insert(0, str(skill_root / 'scripts'))

        # Test data_operations
        print("Testing data_operations module...")
        from data_operations import read_file, create_pivot
        print("  ✓ data_operations imports successful")

        # Test visualization
        print("Testing visualization module...")
        from visualization import create_chart, save_chart
        print("  ✓ visualization imports successful")

        # Test excel_utils
        print("Testing excel_utils module...")
        from excel_utils import save_to_excel
        print("  ✓ excel_utils imports successful")

        # Test with sample data
        print("Testing with sample data...")
        sample_file = skill_root / 'assets' / 'sample_sales_data.csv'

        if sample_file.exists():
            import pandas as pd
            df = pd.read_csv(sample_file)
            print(f"  ✓ Sample data loaded: {len(df)} rows, {len(df.columns)} columns")

            # Test pivot
            pivot = create_pivot(df, index='Region', columns='Product',
                               values='Sales', aggfunc='sum')
            print(f"  ✓ Pivot table created: {pivot.shape[0]}x{pivot.shape[1]}")

        print("=" * 60)
        print("✓ All functionality tests passed!")
        return True

    except Exception as e:
        print("=" * 60)
        print(f"✗ Functionality test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def display_summary(deps_ok, structure_ok, func_ok):
    """Display summary of setup verification"""
    print("\n" + "=" * 60)
    print("SETUP VERIFICATION SUMMARY")
    print("=" * 60)

    results = [
        ("Dependencies", deps_ok),
        ("File Structure", structure_ok),
        ("Functionality", func_ok)
    ]

    for name, status in results:
        status_str = "✓ PASS" if status else "✗ FAIL"
        print(f"{name:20s} : {status_str}")

    print("=" * 60)

    if all([deps_ok, structure_ok, func_ok]):
        print("\n🎉 Excel Data Analyzer skill is ready to use!")
        print("\nYou can now use this skill in Claude Code by:")
        print("  1. Mentioning Excel/CSV operations in your prompts")
        print("  2. Explicitly invoking with @excel-data-analyzer")
        print("\nTry it out:")
        print("  'Analyze the sample_sales_data.csv file'")
        print("  'Create a pivot table showing sales by region'")
    else:
        print("\n⚠️  Setup incomplete. Please address the issues above.")
        if not deps_ok:
            print("\n  Install dependencies:")
            print("    pip install -r requirements.txt")


def main():
    """Main setup verification function"""
    print("\n" + "=" * 60)
    print("EXCEL DATA ANALYZER SKILL - SETUP VERIFICATION")
    print("=" * 60)
    print()

    # Run checks
    deps_ok = check_dependencies()
    structure_ok = check_skill_structure()
    func_ok = test_basic_functionality() if deps_ok else False

    # Display summary
    display_summary(deps_ok, structure_ok, func_ok)

    return all([deps_ok, structure_ok, func_ok])


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
