---
name: code-reviewer
description: Perform comprehensive code reviews checking for security vulnerabilities, performance issues, code quality, best practices, and maintainability. Use when user asks to review code, check for bugs, or evaluate code quality.
metadata:
  short-description: AI-powered code review assistant
  version: 1.0.0
  author: Custom Skill
---

# Code Reviewer

Perform thorough, professional code reviews with a focus on security, performance, maintainability, and best practices.

## When to Use

- User asks you to review code or a pull request
- User requests a security audit of their code
- User wants feedback on code quality
- After implementing a significant feature
- Before committing major changes

## Review Checklist

When reviewing code, systematically check for:

### 1. Security Issues
- [ ] SQL injection vulnerabilities
- [ ] XSS (Cross-Site Scripting) vulnerabilities
- [ ] CSRF protection
- [ ] Exposed secrets or API keys
- [ ] Insecure authentication/authorization
- [ ] Input validation and sanitization
- [ ] Unsafe file operations
- [ ] Command injection risks

### 2. Performance
- [ ] Inefficient loops or algorithms (O(n²) or worse)
- [ ] Unnecessary database queries (N+1 problem)
- [ ] Missing indexes on frequently queried fields
- [ ] Large data loading without pagination
- [ ] Memory leaks or excessive memory usage
- [ ] Blocking operations on main thread
- [ ] Missing caching opportunities

### 3. Code Quality
- [ ] Clear, descriptive variable and function names
- [ ] Functions are focused and do one thing
- [ ] No code duplication (DRY principle)
- [ ] Appropriate error handling
- [ ] Edge cases handled
- [ ] Magic numbers replaced with named constants
- [ ] Comments explain "why", not "what"

### 4. Best Practices
- [ ] Follows language-specific conventions
- [ ] Consistent code style
- [ ] Proper use of async/await
- [ ] Resource cleanup (files, connections, etc.)
- [ ] Appropriate use of design patterns
- [ ] Type safety (if applicable)
- [ ] No deprecated APIs used

### 5. Testing & Maintainability
- [ ] Code is testable
- [ ] Tests cover happy path and edge cases
- [ ] Complex logic has unit tests
- [ ] Minimal coupling between modules
- [ ] Easy to understand and modify

## Review Output Format

Structure your review as follows:

```markdown
## Code Review Summary

**Overall Assessment:** [Good/Needs Improvement/Critical Issues]

### Critical Issues 🔴
[List any security vulnerabilities or breaking bugs]

### Major Issues 🟡
[List significant problems affecting performance or maintainability]

### Minor Issues 🟢
[List style issues, minor optimizations, suggestions]

### Positive Highlights ✨
[Call out well-written code, good practices]

### Recommendations
[Specific actionable items to improve the code]
```

## Review Principles

1. **Be constructive**: Explain WHY something is an issue, not just WHAT is wrong
2. **Provide examples**: Show how to fix issues with code snippets
3. **Prioritize**: Focus on critical issues first
4. **Be specific**: Point to exact file paths and line numbers
5. **Acknowledge good code**: Don't just criticize, praise good practices too
6. **Consider context**: A prototype has different standards than production code

## Language-Specific Checklists

See the references folder for detailed checklists:
- [JavaScript/TypeScript](references/javascript-checklist.md)
- [Python](references/python-checklist.md)
- [General Security](references/security-checklist.md)

## Example Usage

**User:** "Can you review this authentication function?"

**Your Workflow:**
1. Read the code thoroughly
2. Apply the security checklist (authentication is security-critical)
3. Check for common auth vulnerabilities (token storage, password handling, etc.)
4. Review error handling and edge cases
5. Provide structured feedback with code examples
6. Suggest improvements with rationale

## Tips

- Use the Read tool to examine the code before reviewing
- Check related files for context (tests, configuration, dependencies)
- Look for patterns across the codebase
- Consider the user's experience level when providing feedback
- Offer to fix issues if the user wants help implementing changes
