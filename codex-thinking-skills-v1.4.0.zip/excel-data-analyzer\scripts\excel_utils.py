"""
Excel Utilities Module for Excel/CSV Analysis
Provides Excel-specific formatting and utility functions
"""

import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule, CellIsRule
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from pathlib import Path
from typing import Union, List, Optional, Dict, Any


def save_to_excel(
    data: Union[pd.DataFrame, Dict[str, pd.DataFrame]],
    output_path: Union[str, Path],
    sheet_names: Optional[Union[str, List[str]]] = None,
    auto_format: bool = True,
    **kwargs
) -> Path:
    """
    Save DataFrame(s) to Excel with optional auto-formatting.

    Args:
        data: Single DataFrame or dict of DataFrames
        output_path: Output Excel file path
        sheet_names: Sheet name(s) - single string or list
        auto_format: Apply automatic formatting
        **kwargs: Additional arguments for to_excel

    Returns:
        Path to saved file

    Examples:
        >>> save_to_excel(df, 'output.xlsx', sheet_names='Sales')
        >>> save_to_excel({'Sales': df1, 'Returns': df2}, 'report.xlsx')
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        if isinstance(data, pd.DataFrame):
            # Single DataFrame
            sheet_name = sheet_names if isinstance(sheet_names, str) else 'Sheet1'
            data.to_excel(writer, sheet_name=sheet_name, index=False, **kwargs)

            if auto_format:
                format_excel_sheet(writer, sheet_name, data)

        elif isinstance(data, dict):
            # Multiple DataFrames
            for idx, (key, df) in enumerate(data.items()):
                sheet_name = key if not sheet_names else (
                    sheet_names[idx] if isinstance(sheet_names, list) else sheet_names
                )
                df.to_excel(writer, sheet_name=sheet_name, index=False, **kwargs)

                if auto_format:
                    format_excel_sheet(writer, sheet_name, df)

    return output_path


def format_excel_sheet(
    writer: pd.ExcelWriter,
    sheet_name: str,
    df: pd.DataFrame,
    header_color: str = '4472C4',
    header_font_color: str = 'FFFFFF',
    freeze_panes: bool = True,
    auto_filter: bool = True,
    adjust_column_width: bool = True
) -> None:
    """
    Apply formatting to an Excel sheet.

    Args:
        writer: ExcelWriter object
        sheet_name: Name of the sheet to format
        df: DataFrame (to determine dimensions)
        header_color: Header background color (hex)
        header_font_color: Header font color (hex)
        freeze_panes: Freeze the header row
        auto_filter: Enable auto-filter
        adjust_column_width: Auto-adjust column widths
    """
    workbook = writer.book
    worksheet = writer.sheets[sheet_name]

    # Header formatting
    header_fill = PatternFill(start_color=header_color, end_color=header_color, fill_type='solid')
    header_font = Font(color=header_font_color, bold=True, size=11)
    header_alignment = Alignment(horizontal='center', vertical='center')

    for col_num, column in enumerate(df.columns, 1):
        cell = worksheet.cell(row=1, column=col_num)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = header_alignment

    # Freeze panes (freeze first row)
    if freeze_panes:
        worksheet.freeze_panes = 'A2'

    # Auto filter
    if auto_filter:
        worksheet.auto_filter.ref = worksheet.dimensions

    # Adjust column widths
    if adjust_column_width:
        for col_num, column in enumerate(df.columns, 1):
            col_letter = get_column_letter(col_num)
            max_length = max(
                df[column].astype(str).map(len).max(),
                len(str(column))
            )
            adjusted_width = min(max_length + 2, 50)  # Cap at 50
            worksheet.column_dimensions[col_letter].width = adjusted_width

    # Add borders to all cells
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

    for row in worksheet.iter_rows(min_row=1, max_row=len(df) + 1,
                                   min_col=1, max_col=len(df.columns)):
        for cell in row:
            cell.border = thin_border


def add_conditional_formatting(
    workbook_path: Union[str, Path],
    sheet_name: str,
    column: str,
    rule_type: str = 'color_scale',
    start_row: int = 2,
    end_row: Optional[int] = None,
    **kwargs
) -> None:
    """
    Add conditional formatting to a column.

    Args:
        workbook_path: Path to Excel workbook
        sheet_name: Sheet name
        column: Column letter (e.g., 'A', 'B')
        rule_type: Type of rule - 'color_scale', 'data_bar', 'cell_is'
        start_row: Starting row for formatting
        end_row: Ending row (auto-detect if None)
        **kwargs: Additional rule-specific arguments

    Examples:
        >>> add_conditional_formatting('report.xlsx', 'Sales', 'C',
        ...                           rule_type='color_scale')
        >>> add_conditional_formatting('report.xlsx', 'Sales', 'D',
        ...                           rule_type='data_bar')
    """
    workbook = openpyxl.load_workbook(workbook_path)
    worksheet = workbook[sheet_name]

    if end_row is None:
        end_row = worksheet.max_row

    cell_range = f"{column}{start_row}:{column}{end_row}"

    if rule_type == 'color_scale':
        # Three-color scale: red (low) -> yellow (mid) -> green (high)
        rule = ColorScaleRule(
            start_type='min', start_color='F8696B',
            mid_type='percentile', mid_value=50, mid_color='FFEB84',
            end_type='max', end_color='63BE7B'
        )
        worksheet.conditional_formatting.add(cell_range, rule)

    elif rule_type == 'data_bar':
        # Data bar
        rule = DataBarRule(
            start_type='min', end_type='max',
            color=kwargs.get('color', '638EC6')
        )
        worksheet.conditional_formatting.add(cell_range, rule)

    elif rule_type == 'cell_is':
        # Cell value rule
        operator = kwargs.get('operator', 'greaterThan')
        formula = kwargs.get('formula', '0')
        fill = PatternFill(start_color=kwargs.get('color', '00FF00'),
                          end_color=kwargs.get('color', '00FF00'),
                          fill_type='solid')
        rule = CellIsRule(operator=operator, formula=[formula], fill=fill)
        worksheet.conditional_formatting.add(cell_range, rule)

    workbook.save(workbook_path)


def add_excel_chart(
    workbook_path: Union[str, Path],
    sheet_name: str,
    chart_type: str,
    data_range: str,
    categories_range: Optional[str] = None,
    title: Optional[str] = None,
    position: str = 'E2',
    **kwargs
) -> None:
    """
    Add a chart to an Excel sheet.

    Args:
        workbook_path: Path to Excel workbook
        sheet_name: Sheet name
        chart_type: Type of chart - 'bar', 'line', 'pie'
        data_range: Range of data values (e.g., 'B2:B10')
        categories_range: Range of category labels (e.g., 'A2:A10')
        title: Chart title
        position: Cell position for chart (e.g., 'E2')
        **kwargs: Additional chart-specific arguments

    Examples:
        >>> add_excel_chart('report.xlsx', 'Sales', 'bar',
        ...                data_range='B2:B10', categories_range='A2:A10',
        ...                title='Sales by Region')
    """
    workbook = openpyxl.load_workbook(workbook_path)
    worksheet = workbook[sheet_name]

    # Create chart based on type
    if chart_type == 'bar':
        chart = BarChart()
    elif chart_type == 'line':
        chart = LineChart()
    elif chart_type == 'pie':
        chart = PieChart()
    else:
        raise ValueError(f"Unsupported chart type: {chart_type}")

    # Set data
    data = Reference(worksheet, range_string=f"{sheet_name}!{data_range}")
    chart.add_data(data, titles_from_data=False)

    # Set categories if provided
    if categories_range:
        categories = Reference(worksheet, range_string=f"{sheet_name}!{categories_range}")
        chart.set_categories(categories)

    # Set title
    if title:
        chart.title = title

    # Set chart dimensions
    chart.width = kwargs.get('width', 15)
    chart.height = kwargs.get('height', 10)

    # Add chart to worksheet
    worksheet.add_chart(chart, position)

    workbook.save(workbook_path)


def create_pivot_table_excel(
    source_file: Union[str, Path],
    source_sheet: str,
    output_file: Union[str, Path],
    pivot_sheet: str,
    index_cols: List[str],
    value_col: str,
    aggfunc: str = 'sum',
    column_col: Optional[str] = None
) -> Path:
    """
    Create a pivot table in Excel format.

    Args:
        source_file: Path to source Excel file
        source_sheet: Source sheet name
        output_file: Path to output Excel file
        pivot_sheet: Name for pivot table sheet
        index_cols: Columns to use as row index
        value_col: Column to aggregate
        aggfunc: Aggregation function
        column_col: Optional column to use as column headers

    Returns:
        Path to output file

    Example:
        >>> create_pivot_table_excel('sales.xlsx', 'Data', 'pivot.xlsx',
        ...                          'Pivot', ['Region', 'Product'],
        ...                          'Sales', 'sum')
    """
    # Read source data
    df = pd.read_excel(source_file, sheet_name=source_sheet)

    # Create pivot table
    pivot = pd.pivot_table(
        df,
        index=index_cols,
        columns=column_col,
        values=value_col,
        aggfunc=aggfunc,
        fill_value=0
    )

    # Save to Excel
    output_file = Path(output_file)
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # Save original data
        df.to_excel(writer, sheet_name=source_sheet, index=False)
        format_excel_sheet(writer, source_sheet, df)

        # Save pivot table
        pivot.to_excel(writer, sheet_name=pivot_sheet)

        # Format pivot sheet
        worksheet = writer.sheets[pivot_sheet]
        worksheet.freeze_panes = 'B2'

        # Apply formatting
        header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
        header_font = Font(color='FFFFFF', bold=True)

        for row in worksheet.iter_rows(min_row=1, max_row=1):
            for cell in row:
                cell.fill = header_fill
                cell.font = header_font

    return output_file


def merge_excel_files(
    file_paths: List[Union[str, Path]],
    output_path: Union[str, Path],
    sheet_name: Optional[str] = None,
    combine_type: str = 'vertical'
) -> Path:
    """
    Merge multiple Excel files into one.

    Args:
        file_paths: List of Excel file paths
        output_path: Output file path
        sheet_name: Sheet to read from each file (first sheet if None)
        combine_type: 'vertical' (stack rows) or 'horizontal' (add columns)

    Returns:
        Path to output file

    Example:
        >>> merge_excel_files(['jan.xlsx', 'feb.xlsx', 'mar.xlsx'],
        ...                   'q1.xlsx', combine_type='vertical')
    """
    dfs = []

    for file_path in file_paths:
        df = pd.read_excel(file_path, sheet_name=sheet_name or 0)
        dfs.append(df)

    if combine_type == 'vertical':
        merged = pd.concat(dfs, axis=0, ignore_index=True)
    elif combine_type == 'horizontal':
        merged = pd.concat(dfs, axis=1)
    else:
        raise ValueError(f"Invalid combine_type: {combine_type}")

    # Save merged data
    return save_to_excel(merged, output_path, sheet_names='Merged')


def split_excel_by_column(
    source_file: Union[str, Path],
    sheet_name: str,
    split_column: str,
    output_dir: Union[str, Path],
    output_prefix: str = 'split'
) -> List[Path]:
    """
    Split an Excel file into multiple files based on unique values in a column.

    Args:
        source_file: Source Excel file
        sheet_name: Sheet name to read
        split_column: Column to split by
        output_dir: Directory for output files
        output_prefix: Prefix for output file names

    Returns:
        List of output file paths

    Example:
        >>> split_excel_by_column('sales.xlsx', 'Data', 'Region',
        ...                       'output/', 'sales')
        # Creates: sales_East.xlsx, sales_West.xlsx, etc.
    """
    df = pd.read_excel(source_file, sheet_name=sheet_name)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    output_files = []
    unique_values = df[split_column].unique()

    for value in unique_values:
        filtered_df = df[df[split_column] == value]
        output_file = output_dir / f"{output_prefix}_{value}.xlsx"
        save_to_excel(filtered_df, output_file, sheet_names=sheet_name)
        output_files.append(output_file)

    return output_files


def add_summary_sheet(
    workbook_path: Union[str, Path],
    summary_data: Dict[str, Any],
    sheet_name: str = 'Summary'
) -> None:
    """
    Add a summary sheet to an existing Excel workbook.

    Args:
        workbook_path: Path to Excel workbook
        summary_data: Dictionary of summary information
        sheet_name: Name for summary sheet

    Example:
        >>> add_summary_sheet('report.xlsx', {
        ...     'Total Sales': 1000000,
        ...     'Average Order': 250,
        ...     'Top Product': 'Widget A'
        ... })
    """
    workbook = openpyxl.load_workbook(workbook_path)

    # Create summary sheet
    if sheet_name in workbook.sheetnames:
        del workbook[sheet_name]
    worksheet = workbook.create_sheet(sheet_name, 0)

    # Add title
    worksheet['A1'] = 'Summary Report'
    worksheet['A1'].font = Font(size=16, bold=True)

    # Add summary data
    row = 3
    for key, value in summary_data.items():
        worksheet[f'A{row}'] = key
        worksheet[f'B{row}'] = value
        worksheet[f'A{row}'].font = Font(bold=True)
        row += 1

    # Format
    worksheet.column_dimensions['A'].width = 25
    worksheet.column_dimensions['B'].width = 20

    workbook.save(workbook_path)


if __name__ == "__main__":
    # Example usage
    print("Excel Utilities Module - Example Usage")
    print("=" * 50)

    # Create sample data
    sample_df = pd.DataFrame({
        'Product': ['A', 'B', 'C', 'D', 'E'],
        'Sales': [100, 200, 150, 300, 250],
        'Revenue': [1000, 2000, 1500, 3000, 2500],
        'Profit': [200, 400, 300, 600, 500]
    })

    print("\nSample Data:")
    print(sample_df)

    # Save to Excel with formatting
    output_file = save_to_excel(sample_df, 'sample_report.xlsx',
                                sheet_names='Sales Data')
    print(f"\n✓ Excel file saved: {output_file}")

    # Add summary sheet
    summary = {
        'Total Sales': sample_df['Sales'].sum(),
        'Average Revenue': sample_df['Revenue'].mean(),
        'Total Profit': sample_df['Profit'].sum()
    }
    add_summary_sheet(output_file, summary)
    print("✓ Summary sheet added")

    print("\nExcel utilities demonstration complete!")
