"""
Statistical Analysis Module for Excel/CSV Analysis
Provides advanced statistical functions for data analysis
"""

import pandas as pd
import numpy as np
from scipy import stats
from typing import Union, List, Tuple, Dict, Optional
import warnings
warnings.filterwarnings('ignore')


def correlation_analysis(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    method: str = 'pearson'
) -> pd.DataFrame:
    """
    Calculate correlation matrix between columns.

    Args:
        df: DataFrame
        columns: Columns to analyze (all numeric if None)
        method: 'pearson', 'spearman', or 'kendall'

    Returns:
        Correlation matrix DataFrame
    """
    if columns:
        data = df[columns]
    else:
        data = df.select_dtypes(include=[np.number])

    return data.corr(method=method)


def linear_regression(
    df: pd.DataFrame,
    x_col: str,
    y_col: str
) -> Dict:
    """
    Perform simple linear regression.

    Args:
        df: DataFrame
        x_col: Independent variable column
        y_col: Dependent variable column

    Returns:
        Dictionary with regression results
    """
    # Remove missing values
    data = df[[x_col, y_col]].dropna()
    x = data[x_col].values
    y = data[y_col].values

    # Perform regression
    slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)

    # Predictions
    y_pred = slope * x + intercept
    residuals = y - y_pred

    return {
        'slope': slope,
        'intercept': intercept,
        'r_squared': r_value ** 2,
        'r_value': r_value,
        'p_value': p_value,
        'std_err': std_err,
        'equation': f'y = {slope:.4f}x + {intercept:.4f}',
        'predictions': y_pred,
        'residuals': residuals,
        'mean_squared_error': np.mean(residuals ** 2),
        'root_mean_squared_error': np.sqrt(np.mean(residuals ** 2))
    }


def multiple_regression(
    df: pd.DataFrame,
    x_cols: List[str],
    y_col: str
) -> Dict:
    """
    Perform multiple linear regression.

    Args:
        df: DataFrame
        x_cols: List of independent variable columns
        y_col: Dependent variable column

    Returns:
        Dictionary with regression results
    """
    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import r2_score, mean_squared_error

    # Prepare data
    data = df[x_cols + [y_col]].dropna()
    X = data[x_cols].values
    y = data[y_col].values

    # Fit model
    model = LinearRegression()
    model.fit(X, y)

    # Predictions
    y_pred = model.predict(X)

    return {
        'coefficients': dict(zip(x_cols, model.coef_)),
        'intercept': model.intercept_,
        'r_squared': r2_score(y, y_pred),
        'mean_squared_error': mean_squared_error(y, y_pred),
        'root_mean_squared_error': np.sqrt(mean_squared_error(y, y_pred)),
        'predictions': y_pred,
        'residuals': y - y_pred
    }


def t_test(
    group1: pd.Series,
    group2: pd.Series,
    alternative: str = 'two-sided'
) -> Dict:
    """
    Perform independent t-test between two groups.

    Args:
        group1: First group data
        group2: Second group data
        alternative: 'two-sided', 'less', or 'greater'

    Returns:
        Dictionary with test results
    """
    # Remove NaN values
    g1 = group1.dropna()
    g2 = group2.dropna()

    # Perform t-test
    t_stat, p_value = stats.ttest_ind(g1, g2, alternative=alternative)

    # Effect size (Cohen's d)
    pooled_std = np.sqrt((g1.std()**2 + g2.std()**2) / 2)
    cohens_d = (g1.mean() - g2.mean()) / pooled_std

    return {
        't_statistic': t_stat,
        'p_value': p_value,
        'group1_mean': g1.mean(),
        'group2_mean': g2.mean(),
        'group1_std': g1.std(),
        'group2_std': g2.std(),
        'cohens_d': cohens_d,
        'significant': p_value < 0.05,
        'interpretation': 'Significant difference' if p_value < 0.05 else 'No significant difference'
    }


def anova_test(
    df: pd.DataFrame,
    value_col: str,
    group_col: str
) -> Dict:
    """
    Perform one-way ANOVA test.

    Args:
        df: DataFrame
        value_col: Column with values to compare
        group_col: Column with group labels

    Returns:
        Dictionary with ANOVA results
    """
    # Prepare groups
    groups = [group[value_col].dropna() for name, group in df.groupby(group_col)]

    # Perform ANOVA
    f_stat, p_value = stats.f_oneway(*groups)

    # Group statistics
    group_stats = df.groupby(group_col)[value_col].agg(['mean', 'std', 'count'])

    return {
        'f_statistic': f_stat,
        'p_value': p_value,
        'significant': p_value < 0.05,
        'group_statistics': group_stats,
        'interpretation': 'Significant difference between groups' if p_value < 0.05
                         else 'No significant difference between groups'
    }


def chi_square_test(
    df: pd.DataFrame,
    col1: str,
    col2: str
) -> Dict:
    """
    Perform chi-square test of independence.

    Args:
        df: DataFrame
        col1: First categorical column
        col2: Second categorical column

    Returns:
        Dictionary with test results
    """
    # Create contingency table
    contingency = pd.crosstab(df[col1], df[col2])

    # Perform chi-square test
    chi2, p_value, dof, expected = stats.chi2_contingency(contingency)

    # Cramér's V (effect size)
    n = contingency.sum().sum()
    min_dim = min(contingency.shape[0] - 1, contingency.shape[1] - 1)
    cramers_v = np.sqrt(chi2 / (n * min_dim))

    return {
        'chi_square': chi2,
        'p_value': p_value,
        'degrees_of_freedom': dof,
        'cramers_v': cramers_v,
        'contingency_table': contingency,
        'expected_frequencies': pd.DataFrame(expected,
                                            index=contingency.index,
                                            columns=contingency.columns),
        'significant': p_value < 0.05,
        'interpretation': 'Significant association' if p_value < 0.05
                         else 'No significant association'
    }


def normality_test(
    data: pd.Series,
    method: str = 'shapiro'
) -> Dict:
    """
    Test if data follows normal distribution.

    Args:
        data: Data series
        method: 'shapiro' or 'kstest'

    Returns:
        Dictionary with test results
    """
    clean_data = data.dropna()

    if method == 'shapiro':
        stat, p_value = stats.shapiro(clean_data)
        test_name = 'Shapiro-Wilk'
    elif method == 'kstest':
        stat, p_value = stats.kstest(clean_data, 'norm')
        test_name = 'Kolmogorov-Smirnov'
    else:
        raise ValueError(f"Unknown method: {method}")

    return {
        'test': test_name,
        'statistic': stat,
        'p_value': p_value,
        'is_normal': p_value > 0.05,
        'interpretation': 'Data appears normally distributed' if p_value > 0.05
                         else 'Data does not appear normally distributed'
    }


def outlier_detection(
    data: pd.Series,
    method: str = 'iqr',
    threshold: float = 1.5
) -> Dict:
    """
    Detect outliers in data.

    Args:
        data: Data series
        method: 'iqr' (Interquartile Range) or 'zscore'
        threshold: 1.5 for IQR (standard), or 3 for Z-score

    Returns:
        Dictionary with outlier information
    """
    clean_data = data.dropna()

    if method == 'iqr':
        Q1 = clean_data.quantile(0.25)
        Q3 = clean_data.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - threshold * IQR
        upper_bound = Q3 + threshold * IQR
        outliers = (clean_data < lower_bound) | (clean_data > upper_bound)

    elif method == 'zscore':
        z_scores = np.abs(stats.zscore(clean_data))
        outliers = z_scores > threshold
        lower_bound = clean_data.mean() - threshold * clean_data.std()
        upper_bound = clean_data.mean() + threshold * clean_data.std()

    else:
        raise ValueError(f"Unknown method: {method}")

    outlier_values = clean_data[outliers]

    return {
        'method': method,
        'threshold': threshold,
        'lower_bound': lower_bound,
        'upper_bound': upper_bound,
        'n_outliers': outliers.sum(),
        'outlier_percentage': (outliers.sum() / len(clean_data)) * 100,
        'outlier_indices': outlier_values.index.tolist(),
        'outlier_values': outlier_values.tolist(),
        'is_outlier': outliers
    }


def percentile_analysis(
    df: pd.DataFrame,
    column: str,
    percentiles: List[float] = [0.25, 0.5, 0.75, 0.9, 0.95, 0.99]
) -> pd.DataFrame:
    """
    Calculate percentile statistics for a column.

    Args:
        df: DataFrame
        column: Column to analyze
        percentiles: List of percentiles (0-1)

    Returns:
        DataFrame with percentile values
    """
    values = df[column].quantile(percentiles)
    result = pd.DataFrame({
        'Percentile': [f'{int(p*100)}th' for p in percentiles],
        'Value': values.values
    })

    return result


def statistical_summary(
    df: pd.DataFrame,
    column: str,
    include_advanced: bool = True
) -> Dict:
    """
    Generate comprehensive statistical summary for a column.

    Args:
        df: DataFrame
        column: Column to analyze
        include_advanced: Include skewness, kurtosis, etc.

    Returns:
        Dictionary with statistics
    """
    data = df[column].dropna()

    summary = {
        'count': len(data),
        'mean': data.mean(),
        'median': data.median(),
        'mode': data.mode().iloc[0] if len(data.mode()) > 0 else None,
        'std': data.std(),
        'variance': data.var(),
        'min': data.min(),
        'max': data.max(),
        'range': data.max() - data.min(),
        'q1': data.quantile(0.25),
        'q3': data.quantile(0.75),
        'iqr': data.quantile(0.75) - data.quantile(0.25)
    }

    if include_advanced:
        summary.update({
            'skewness': stats.skew(data),
            'kurtosis': stats.kurtosis(data),
            'coefficient_of_variation': (data.std() / data.mean()) * 100 if data.mean() != 0 else None,
            'sem': stats.sem(data),  # Standard error of mean
            'missing_count': df[column].isna().sum(),
            'missing_percentage': (df[column].isna().sum() / len(df)) * 100
        })

    return summary


def confidence_interval(
    data: pd.Series,
    confidence: float = 0.95
) -> Tuple[float, float]:
    """
    Calculate confidence interval for the mean.

    Args:
        data: Data series
        confidence: Confidence level (e.g., 0.95 for 95%)

    Returns:
        Tuple of (lower_bound, upper_bound)
    """
    clean_data = data.dropna()
    mean = clean_data.mean()
    sem = stats.sem(clean_data)
    margin = sem * stats.t.ppf((1 + confidence) / 2, len(clean_data) - 1)

    return (mean - margin, mean + margin)


def proportion_test(
    successes1: int,
    n1: int,
    successes2: int,
    n2: int,
    alternative: str = 'two-sided'
) -> Dict:
    """
    Test if two proportions are significantly different.

    Args:
        successes1: Number of successes in group 1
        n1: Total size of group 1
        successes2: Number of successes in group 2
        n2: Total size of group 2
        alternative: 'two-sided', 'less', or 'greater'

    Returns:
        Dictionary with test results
    """
    from statsmodels.stats.proportion import proportions_ztest

    counts = np.array([successes1, successes2])
    nobs = np.array([n1, n2])

    z_stat, p_value = proportions_ztest(counts, nobs, alternative=alternative)

    prop1 = successes1 / n1
    prop2 = successes2 / n2

    return {
        'z_statistic': z_stat,
        'p_value': p_value,
        'proportion1': prop1,
        'proportion2': prop2,
        'difference': prop1 - prop2,
        'significant': p_value < 0.05,
        'interpretation': 'Proportions are significantly different' if p_value < 0.05
                         else 'No significant difference in proportions'
    }


def variance_test(
    group1: pd.Series,
    group2: pd.Series
) -> Dict:
    """
    Test if two groups have equal variances (Levene's test).

    Args:
        group1: First group data
        group2: Second group data

    Returns:
        Dictionary with test results
    """
    g1 = group1.dropna()
    g2 = group2.dropna()

    stat, p_value = stats.levene(g1, g2)

    return {
        'statistic': stat,
        'p_value': p_value,
        'group1_variance': g1.var(),
        'group2_variance': g2.var(),
        'equal_variances': p_value > 0.05,
        'interpretation': 'Variances are equal' if p_value > 0.05
                         else 'Variances are significantly different'
    }


if __name__ == "__main__":
    # Example usage
    print("Statistical Analysis Module - Example Usage")
    print("=" * 60)

    # Create sample data
    np.random.seed(42)
    df = pd.DataFrame({
        'Sales': np.random.normal(1000, 200, 100),
        'Marketing': np.random.normal(500, 100, 100),
        'Region': np.random.choice(['North', 'South', 'East', 'West'], 100),
        'Category': np.random.choice(['A', 'B'], 100)
    })

    # Correlation
    print("\nCorrelation Analysis:")
    corr = correlation_analysis(df, ['Sales', 'Marketing'])
    print(corr)

    # Linear regression
    print("\nLinear Regression (Marketing vs Sales):")
    reg = linear_regression(df, 'Marketing', 'Sales')
    print(f"Equation: {reg['equation']}")
    print(f"R-squared: {reg['r_squared']:.4f}")
    print(f"P-value: {reg['p_value']:.4f}")

    # T-test
    print("\nT-Test (Category A vs B):")
    group_a = df[df['Category'] == 'A']['Sales']
    group_b = df[df['Category'] == 'B']['Sales']
    t_result = t_test(group_a, group_b)
    print(f"P-value: {t_result['p_value']:.4f}")
    print(f"Result: {t_result['interpretation']}")

    # ANOVA
    print("\nANOVA (Sales across Regions):")
    anova = anova_test(df, 'Sales', 'Region')
    print(f"F-statistic: {anova['f_statistic']:.4f}")
    print(f"P-value: {anova['p_value']:.4f}")
    print(f"Result: {anova['interpretation']}")

    # Outlier detection
    print("\nOutlier Detection (Sales):")
    outliers = outlier_detection(df['Sales'], method='iqr')
    print(f"Number of outliers: {outliers['n_outliers']}")
    print(f"Percentage: {outliers['outlier_percentage']:.2f}%")

    print("\nStatistical analysis demonstration complete!")
