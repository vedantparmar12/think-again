"""
Business Analytics Module for Excel/CSV Analysis
Provides business-specific analytics: RFM, KPIs, Funnels, A/B Testing, etc.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')


def rfm_analysis(
    df: pd.DataFrame,
    customer_col: str,
    date_col: str,
    revenue_col: str,
    reference_date: Optional[datetime] = None
) -> pd.DataFrame:
    """
    Perform RFM (Recency, Frequency, Monetary) analysis.

    Args:
        df: DataFrame with transaction data
        customer_col: Column with customer IDs
        date_col: Column with transaction dates
        revenue_col: Column with transaction amounts
        reference_date: Reference date for recency (defaults to max date + 1 day)

    Returns:
        DataFrame with RFM scores and segments
    """
    # Ensure date column is datetime
    df_copy = df.copy()
    df_copy[date_col] = pd.to_datetime(df_copy[date_col])

    if reference_date is None:
        reference_date = df_copy[date_col].max() + timedelta(days=1)

    # Calculate RFM metrics
    rfm = df_copy.groupby(customer_col).agg({
        date_col: lambda x: (reference_date - x.max()).days,  # Recency
        customer_col: 'count',  # Frequency
        revenue_col: 'sum'  # Monetary
    })

    rfm.columns = ['Recency', 'Frequency', 'Monetary']

    # Calculate RFM scores (1-5, where 5 is best)
    rfm['R_Score'] = pd.qcut(rfm['Recency'], 5, labels=[5, 4, 3, 2, 1], duplicates='drop')
    rfm['F_Score'] = pd.qcut(rfm['Frequency'].rank(method='first'), 5, labels=[1, 2, 3, 4, 5], duplicates='drop')
    rfm['M_Score'] = pd.qcut(rfm['Monetary'], 5, labels=[1, 2, 3, 4, 5], duplicates='drop')

    # Convert to numeric
    rfm['R_Score'] = rfm['R_Score'].astype(int)
    rfm['F_Score'] = rfm['F_Score'].astype(int)
    rfm['M_Score'] = rfm['M_Score'].astype(int)

    # Calculate RFM composite score
    rfm['RFM_Score'] = rfm['R_Score'].astype(str) + rfm['F_Score'].astype(str) + rfm['M_Score'].astype(str)

    # Segment customers
    rfm['Segment'] = rfm.apply(segment_customer, axis=1)

    # Add customer lifetime value
    rfm['CLV'] = rfm['Monetary'] / rfm['Frequency']

    return rfm.reset_index()


def segment_customer(row) -> str:
    """Segment customers based on RFM scores."""
    r, f, m = row['R_Score'], row['F_Score'], row['M_Score']

    if r >= 4 and f >= 4 and m >= 4:
        return 'Champions'
    elif r >= 3 and f >= 3 and m >= 3:
        return 'Loyal Customers'
    elif r >= 4 and f <= 2:
        return 'New Customers'
    elif r <= 2 and f >= 3:
        return 'At Risk'
    elif r <= 2 and f <= 2:
        return 'Lost'
    elif r >= 3 and f <= 2:
        return 'Potential Loyalists'
    elif m >= 4:
        return 'Big Spenders'
    else:
        return 'Need Attention'


def cohort_analysis(
    df: pd.DataFrame,
    customer_col: str,
    date_col: str,
    metric_col: str,
    period: str = 'M'
) -> pd.DataFrame:
    """
    Perform cohort analysis (retention/revenue by cohort).

    Args:
        df: DataFrame with transaction data
        customer_col: Column with customer IDs
        date_col: Column with dates
        metric_col: Column to aggregate (e.g., revenue)
        period: Time period ('M' for month, 'W' for week, 'D' for day)

    Returns:
        Cohort analysis DataFrame
    """
    df_copy = df.copy()
    df_copy[date_col] = pd.to_datetime(df_copy[date_col])

    # Determine first purchase date for each customer
    df_copy['CohortDate'] = df_copy.groupby(customer_col)[date_col].transform('min')

    # Create cohort and transaction periods
    df_copy['CohortPeriod'] = df_copy['CohortDate'].dt.to_period(period)
    df_copy['TransactionPeriod'] = df_copy[date_col].dt.to_period(period)

    # Calculate periods since cohort
    df_copy['PeriodNumber'] = (
        (df_copy['TransactionPeriod'] - df_copy['CohortPeriod']).apply(lambda x: x.n)
    )

    # Create cohort pivot
    cohort = df_copy.groupby(['CohortPeriod', 'PeriodNumber'])[customer_col].nunique().reset_index()
    cohort_pivot = cohort.pivot(index='CohortPeriod', columns='PeriodNumber', values=customer_col)

    # Calculate retention rates
    cohort_size = cohort_pivot.iloc[:, 0]
    retention = cohort_pivot.divide(cohort_size, axis=0) * 100

    return retention


def funnel_analysis(
    df: pd.DataFrame,
    stages: List[str],
    user_col: str,
    stage_col: str
) -> pd.DataFrame:
    """
    Analyze conversion funnel.

    Args:
        df: DataFrame with user journey data
        stages: Ordered list of funnel stages
        user_col: Column with user identifiers
        stage_col: Column with stage names

    Returns:
        DataFrame with funnel metrics
    """
    funnel_data = []

    for i, stage in enumerate(stages):
        users_in_stage = df[df[stage_col] == stage][user_col].nunique()

        if i == 0:
            conversion_from_previous = 100.0
            conversion_from_top = 100.0
            previous_users = users_in_stage
        else:
            conversion_from_previous = (users_in_stage / previous_users * 100) if previous_users > 0 else 0
            conversion_from_top = (users_in_stage / funnel_data[0]['Users'] * 100) if funnel_data[0]['Users'] > 0 else 0
            drop_off = previous_users - users_in_stage

        funnel_data.append({
            'Stage': stage,
            'Users': users_in_stage,
            'Conversion from Previous (%)': conversion_from_previous,
            'Conversion from Top (%)': conversion_from_top,
            'Drop-off': users_in_stage if i == 0 else drop_off,
            'Drop-off (%)': 0 if i == 0 else (100 - conversion_from_previous)
        })

        previous_users = users_in_stage

    return pd.DataFrame(funnel_data)


def ab_test_analysis(
    control_data: pd.Series,
    treatment_data: pd.Series,
    metric_name: str = 'Metric'
) -> Dict:
    """
    Analyze A/B test results.

    Args:
        control_data: Control group metric values
        treatment_data: Treatment group metric values
        metric_name: Name of the metric being tested

    Returns:
        Dictionary with A/B test results
    """
    from scipy import stats

    # Clean data
    control = control_data.dropna()
    treatment = treatment_data.dropna()

    # Calculate statistics
    control_mean = control.mean()
    treatment_mean = treatment.mean()
    control_std = control.std()
    treatment_std = treatment.std()

    # Perform t-test
    t_stat, p_value = stats.ttest_ind(control, treatment)

    # Effect size (Cohen's d)
    pooled_std = np.sqrt((control_std**2 + treatment_std**2) / 2)
    cohens_d = (treatment_mean - control_mean) / pooled_std

    # Confidence interval for difference
    diff_mean = treatment_mean - control_mean
    diff_se = np.sqrt(control_std**2/len(control) + treatment_std**2/len(treatment))
    ci_lower = diff_mean - 1.96 * diff_se
    ci_upper = diff_mean + 1.96 * diff_se

    # Lift calculation
    lift = ((treatment_mean - control_mean) / control_mean * 100) if control_mean != 0 else 0

    # Statistical power (simplified)
    from scipy.stats import norm
    z_alpha = norm.ppf(0.975)  # two-tailed, alpha=0.05
    z_beta = (abs(diff_mean) - z_alpha * diff_se) / diff_se
    power = norm.cdf(z_beta)

    return {
        'metric': metric_name,
        'control': {
            'n': len(control),
            'mean': control_mean,
            'std': control_std
        },
        'treatment': {
            'n': len(treatment),
            'mean': treatment_mean,
            'std': treatment_std
        },
        'difference': {
            'absolute': diff_mean,
            'lift_percentage': lift,
            'confidence_interval': (ci_lower, ci_upper)
        },
        'statistical_test': {
            't_statistic': t_stat,
            'p_value': p_value,
            'cohens_d': cohens_d,
            'significant': p_value < 0.05,
            'power': power
        },
        'recommendation': 'Deploy treatment' if p_value < 0.05 and lift > 0
                         else 'Keep control' if p_value < 0.05 and lift < 0
                         else 'Needs more data'
    }


def calculate_kpis(
    df: pd.DataFrame,
    kpi_config: Dict[str, Dict]
) -> Dict:
    """
    Calculate business KPIs.

    Args:
        df: DataFrame with business data
        kpi_config: Configuration for KPIs
                   Example: {'revenue': {'column': 'Sales', 'aggregation': 'sum'},
                            'avg_order': {'column': 'OrderValue', 'aggregation': 'mean'}}

    Returns:
        Dictionary with KPI values
    """
    kpis = {}

    for kpi_name, config in kpi_config.items():
        col = config['column']
        agg = config['aggregation']

        if agg == 'sum':
            kpis[kpi_name] = df[col].sum()
        elif agg == 'mean':
            kpis[kpi_name] = df[col].mean()
        elif agg == 'median':
            kpis[kpi_name] = df[col].median()
        elif agg == 'count':
            kpis[kpi_name] = df[col].count()
        elif agg == 'nunique':
            kpis[kpi_name] = df[col].nunique()
        elif agg == 'min':
            kpis[kpi_name] = df[col].min()
        elif agg == 'max':
            kpis[kpi_name] = df[col].max()
        elif callable(agg):
            kpis[kpi_name] = agg(df[col])

    return kpis


def customer_lifetime_value(
    df: pd.DataFrame,
    customer_col: str,
    revenue_col: str,
    date_col: str,
    discount_rate: float = 0.1
) -> pd.DataFrame:
    """
    Calculate Customer Lifetime Value (CLV).

    Args:
        df: DataFrame with transaction data
        customer_col: Column with customer IDs
        revenue_col: Column with revenue
        date_col: Column with dates
        discount_rate: Annual discount rate for NPV calculation

    Returns:
        DataFrame with CLV per customer
    """
    df_copy = df.copy()
    df_copy[date_col] = pd.to_datetime(df_copy[date_col])

    # Calculate metrics per customer
    clv_df = df_copy.groupby(customer_col).agg({
        revenue_col: ['sum', 'mean', 'count'],
        date_col: ['min', 'max']
    })

    clv_df.columns = ['total_revenue', 'avg_revenue', 'purchase_count', 'first_purchase', 'last_purchase']

    # Calculate customer lifespan in days
    clv_df['lifespan_days'] = (clv_df['last_purchase'] - clv_df['first_purchase']).dt.days

    # Average days between purchases
    clv_df['avg_days_between_purchases'] = clv_df['lifespan_days'] / (clv_df['purchase_count'] - 1)
    clv_df['avg_days_between_purchases'] = clv_df['avg_days_between_purchases'].fillna(0)

    # Estimate purchase frequency per year
    clv_df['annual_purchase_frequency'] = 365 / clv_df['avg_days_between_purchases']
    clv_df['annual_purchase_frequency'] = clv_df['annual_purchase_frequency'].replace([np.inf, -np.inf], 0)

    # Estimate annual value
    clv_df['annual_value'] = clv_df['avg_revenue'] * clv_df['annual_purchase_frequency']

    # Simple CLV (3-year horizon)
    years = 3
    clv_df['clv_3yr'] = sum([
        clv_df['annual_value'] / ((1 + discount_rate) ** year)
        for year in range(1, years + 1)
    ])

    # Customer value tier
    clv_df['value_tier'] = pd.qcut(
        clv_df['clv_3yr'],
        q=4,
        labels=['Bronze', 'Silver', 'Gold', 'Platinum'],
        duplicates='drop'
    )

    return clv_df.reset_index()


def churn_prediction_features(
    df: pd.DataFrame,
    customer_col: str,
    date_col: str,
    revenue_col: str,
    reference_date: Optional[datetime] = None
) -> pd.DataFrame:
    """
    Create features for churn prediction.

    Args:
        df: DataFrame with transaction data
        customer_col: Column with customer IDs
        date_col: Column with dates
        revenue_col: Column with revenue
        reference_date: Reference date (defaults to max date)

    Returns:
        DataFrame with churn prediction features
    """
    df_copy = df.copy()
    df_copy[date_col] = pd.to_datetime(df_copy[date_col])

    if reference_date is None:
        reference_date = df_copy[date_col].max()

    features = df_copy.groupby(customer_col).agg({
        date_col: ['min', 'max', 'count'],
        revenue_col: ['sum', 'mean', 'std', 'min', 'max']
    })

    features.columns = [
        'first_purchase_date', 'last_purchase_date', 'purchase_count',
        'total_revenue', 'avg_revenue', 'std_revenue', 'min_revenue', 'max_revenue'
    ]

    # Recency (days since last purchase)
    features['recency_days'] = (reference_date - features['last_purchase_date']).dt.days

    # Customer age (days since first purchase)
    features['customer_age_days'] = (reference_date - features['first_purchase_date']).dt.days

    # Purchase frequency
    features['purchase_frequency'] = (
        features['purchase_count'] / features['customer_age_days'] * 30
    )  # Monthly frequency

    # Engagement trend (comparing recent vs historical)
    recent_cutoff = reference_date - timedelta(days=90)
    recent_purchases = df_copy[df_copy[date_col] >= recent_cutoff].groupby(customer_col).size()
    features['recent_purchases_90d'] = recent_purchases
    features['recent_purchases_90d'] = features['recent_purchases_90d'].fillna(0)

    # Churn risk score (simple rule-based)
    features['churn_risk'] = 'Low'
    features.loc[features['recency_days'] > 90, 'churn_risk'] = 'Medium'
    features.loc[features['recency_days'] > 180, 'churn_risk'] = 'High'
    features.loc[
        (features['recency_days'] > 365) | (features['purchase_count'] == 1),
        'churn_risk'
    ] = 'Critical'

    return features.reset_index()


def market_basket_analysis(
    df: pd.DataFrame,
    transaction_col: str,
    product_col: str,
    min_support: float = 0.01
) -> pd.DataFrame:
    """
    Perform market basket analysis (frequent itemsets).

    Args:
        df: DataFrame with transaction data
        transaction_col: Column with transaction IDs
        product_col: Column with product names
        min_support: Minimum support threshold

    Returns:
        DataFrame with product associations
    """
    try:
        from mlxtend.frequent_patterns import apriori, association_rules
        from mlxtend.preprocessing import TransactionEncoder
    except ImportError:
        raise ImportError("mlxtend is required for market basket analysis. Install with: pip install mlxtend")

    # Create transaction list
    transactions = df.groupby(transaction_col)[product_col].apply(list).tolist()

    # Encode transactions
    te = TransactionEncoder()
    te_array = te.fit(transactions).transform(transactions)
    basket_df = pd.DataFrame(te_array, columns=te.columns_)

    # Find frequent itemsets
    frequent_itemsets = apriori(basket_df, min_support=min_support, use_colnames=True)

    # Generate association rules
    if len(frequent_itemsets) > 0:
        rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.5)
        rules = rules.sort_values('lift', ascending=False)
        return rules
    else:
        return pd.DataFrame()


def revenue_attribution(
    df: pd.DataFrame,
    revenue_col: str,
    dimension_cols: List[str]
) -> Dict[str, pd.DataFrame]:
    """
    Attribute revenue across multiple dimensions.

    Args:
        df: DataFrame with revenue data
        revenue_col: Column with revenue
        dimension_cols: List of columns to attribute revenue by

    Returns:
        Dictionary of attribution DataFrames by dimension
    """
    attributions = {}

    total_revenue = df[revenue_col].sum()

    for dim in dimension_cols:
        dim_revenue = df.groupby(dim)[revenue_col].agg(['sum', 'count', 'mean'])
        dim_revenue.columns = ['Revenue', 'Transactions', 'Avg_Transaction']
        dim_revenue['Revenue_%'] = (dim_revenue['Revenue'] / total_revenue * 100)
        dim_revenue = dim_revenue.sort_values('Revenue', ascending=False)

        attributions[dim] = dim_revenue.reset_index()

    return attributions


if __name__ == "__main__":
    # Example usage
    print("Business Analytics Module - Example Usage")
    print("=" * 70)

    # Create sample transaction data
    np.random.seed(42)
    n_transactions = 500

    customers = [f'C{i:03d}' for i in range(1, 101)]
    dates = pd.date_range('2023-01-01', '2024-12-31', periods=n_transactions)

    df = pd.DataFrame({
        'CustomerID': np.random.choice(customers, n_transactions),
        'Date': np.random.choice(dates, n_transactions),
        'Revenue': np.random.uniform(10, 500, n_transactions),
        'Product': np.random.choice(['A', 'B', 'C', 'D'], n_transactions)
    })

    # RFM Analysis
    print("\nRFM ANALYSIS")
    print("-" * 70)
    rfm = rfm_analysis(df, 'CustomerID', 'Date', 'Revenue')
    print(rfm.head())
    print(f"\nSegment Distribution:")
    print(rfm['Segment'].value_counts())

    # CLV Calculation
    print("\nCUSTOMER LIFETIME VALUE")
    print("-" * 70)
    clv = customer_lifetime_value(df, 'CustomerID', 'Revenue', 'Date')
    print(clv.nlargest(5, 'clv_3yr')[['CustomerID', 'clv_3yr', 'value_tier']])

    # Funnel Analysis
    funnel_df = pd.DataFrame({
        'UserID': range(1, 1001),
        'Stage': np.random.choice(['Visit', 'Browse', 'Cart', 'Purchase'], 1000,
                                 p=[0.4, 0.3, 0.2, 0.1])
    })

    print("\nFUNNEL ANALYSIS")
    print("-" * 70)
    funnel = funnel_analysis(funnel_df, ['Visit', 'Browse', 'Cart', 'Purchase'],
                            'UserID', 'Stage')
    print(funnel)

    print("\nBusiness analytics demonstration complete!")
