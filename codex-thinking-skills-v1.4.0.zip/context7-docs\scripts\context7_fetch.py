#!/usr/bin/env python3
"""
Context7 Documentation Fetcher

Fetches up-to-date library documentation from Context7 API.
Supports searching for libraries and retrieving topic-specific documentation.

Usage:
    python3 context7_fetch.py search "library-name"
    python3 context7_fetch.py docs "/org/project" [--topic TOPIC] [--tokens N]

Environment:
    CONTEXT7_API_KEY: Optional API key for higher rate limits
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.parse
import urllib.error

# API Configuration
API_BASE_URL = "https://api.context7.com/v1"
DEFAULT_TOKENS = 5000
MIN_TOKENS = 1000


def get_headers() -> dict:
    """Build request headers with optional API key."""
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    api_key = os.environ.get("CONTEXT7_API_KEY")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    return headers


def search_libraries(query: str) -> None:
    """
    Search for libraries by name and display Context7-compatible IDs.

    Args:
        query: Library name to search for (e.g., "nextjs", "react query")
    """
    url = f"{API_BASE_URL}/search?q={urllib.parse.quote(query)}"

    try:
        req = urllib.request.Request(url, headers=get_headers())
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode())
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} - {e.reason}", file=sys.stderr)
        if e.code == 429:
            print("Rate limited. Set CONTEXT7_API_KEY for higher limits.", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"Error: Connection failed - {e.reason}", file=sys.stderr)
        sys.exit(1)

    if "error" in data:
        print(f"Error: {data['error']}", file=sys.stderr)
        sys.exit(1)

    results = data.get("results", [])
    if not results:
        print(f"No libraries found for '{query}'")
        print("\nTry different search terms or check spelling.")
        return

    print(f"\n=== Context7 Library Search: '{query}' ===\n")

    for i, lib in enumerate(results[:10], 1):
        lib_id = lib.get("id", "N/A")
        name = lib.get("name", lib.get("title", "Unknown"))
        snippets = lib.get("codeSnippetCount", lib.get("snippets", 0))
        source = lib.get("sourceReputation", lib.get("source", ""))
        versions = lib.get("versions", [])

        print(f"{i}. {name}")
        print(f"   ID: {lib_id}")
        if snippets:
            print(f"   Code snippets: {snippets}")
        if source:
            print(f"   Source: {source}")
        if versions:
            print(f"   Versions: {', '.join(versions[:5])}")
        print()

    print("=" * 50)
    print("\nTo fetch docs, use:")
    print(f"  python3 context7_fetch.py docs \"{results[0].get('id', '/org/project')}\"")


def fetch_docs(library_id: str, topic: str = None, tokens: int = DEFAULT_TOKENS) -> None:
    """
    Fetch documentation for a specific library.

    Args:
        library_id: Context7 library ID (e.g., "/vercel/next.js")
        topic: Optional topic to focus on (e.g., "routing", "hooks")
        tokens: Maximum tokens to retrieve (default: 5000)
    """
    # Validate library ID format
    if not library_id.startswith("/"):
        print(f"Warning: Library ID should start with '/'. Got: {library_id}", file=sys.stderr)
        print("Run 'search' command to find the correct library ID.", file=sys.stderr)
        library_id = "/" + library_id

    # Enforce minimum tokens
    tokens = max(tokens, MIN_TOKENS)

    # Build URL with query parameters
    params = {"tokens": str(tokens)}
    if topic:
        params["topic"] = topic

    query_string = urllib.parse.urlencode(params)
    url = f"{API_BASE_URL}/docs{library_id}?{query_string}"

    try:
        req = urllib.request.Request(url, headers=get_headers())
        with urllib.request.urlopen(req, timeout=60) as response:
            data = json.loads(response.read().decode())
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} - {e.reason}", file=sys.stderr)
        if e.code == 404:
            print(f"Library '{library_id}' not found.", file=sys.stderr)
            print("Run 'search' command to find the correct library ID.", file=sys.stderr)
        elif e.code == 429:
            print("Rate limited. Set CONTEXT7_API_KEY for higher limits.", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"Error: Connection failed - {e.reason}", file=sys.stderr)
        sys.exit(1)

    if "error" in data:
        print(f"Error: {data['error']}", file=sys.stderr)
        sys.exit(1)

    # Handle different response formats
    content = data.get("content") or data.get("documentation") or data.get("text")

    if not content:
        if data.get("chunks"):
            # Handle chunked response
            chunks = data["chunks"]
            content = "\n\n---\n\n".join(
                chunk.get("content", chunk.get("text", ""))
                for chunk in chunks
            )
        elif isinstance(data, str):
            content = data
        else:
            print("Documentation not found or not finalized.", file=sys.stderr)
            print("The library may still be indexing. Try again later.", file=sys.stderr)
            sys.exit(1)

    # Print documentation
    header = f"\n=== Documentation: {library_id}"
    if topic:
        header += f" (topic: {topic})"
    header += f" ===\n"
    print(header)
    print(content)
    print("\n" + "=" * 50)


def main():
    parser = argparse.ArgumentParser(
        description="Fetch up-to-date library documentation from Context7",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Search for a library:
    python3 context7_fetch.py search "nextjs"
    python3 context7_fetch.py search "react query"

  Fetch documentation:
    python3 context7_fetch.py docs "/vercel/next.js"
    python3 context7_fetch.py docs "/tanstack/query" --topic "mutations"
    python3 context7_fetch.py docs "/prisma/prisma" --tokens 10000

Environment:
  CONTEXT7_API_KEY    Optional API key for higher rate limits
                      Get yours at: https://context7.com/dashboard
        """
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # Search subcommand
    search_parser = subparsers.add_parser(
        "search",
        help="Search for libraries by name"
    )
    search_parser.add_argument(
        "query",
        help="Library name to search for"
    )

    # Docs subcommand
    docs_parser = subparsers.add_parser(
        "docs",
        help="Fetch documentation for a library"
    )
    docs_parser.add_argument(
        "library_id",
        help="Context7 library ID (e.g., /vercel/next.js)"
    )
    docs_parser.add_argument(
        "--topic", "-t",
        help="Focus on specific topic (e.g., 'routing', 'hooks')"
    )
    docs_parser.add_argument(
        "--tokens", "-n",
        type=int,
        default=DEFAULT_TOKENS,
        help=f"Max tokens to retrieve (default: {DEFAULT_TOKENS}, min: {MIN_TOKENS})"
    )

    args = parser.parse_args()

    if args.command == "search":
        search_libraries(args.query)
    elif args.command == "docs":
        fetch_docs(args.library_id, args.topic, args.tokens)


if __name__ == "__main__":
    main()
