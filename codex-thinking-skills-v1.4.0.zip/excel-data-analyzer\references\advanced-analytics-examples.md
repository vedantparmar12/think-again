# Advanced Analytics Examples

This document showcases the advanced analytics capabilities added to the Excel Data Analyzer skill, including statistical analysis, data profiling, business analytics, and forecasting.

## Statistical Analysis Examples

### Example 1: Correlation and Regression Analysis

```python
import sys
sys.path.append('C:/Users/vedan/.codex/skills/excel-data-analyzer/scripts')
from data_operations import read_file
from statistical_analysis import correlation_analysis, linear_regression
from visualization import create_chart, save_chart

# Load sales data
df = read_file('marketing_sales.xlsx')

# 1. Correlation Analysis
print("Correlation Analysis:")
corr = correlation_analysis(df, ['MarketingSpend', 'Sales', 'WebsiteTraffic'], method='pearson')
print(corr)

# 2. Linear Regression: Marketing Spend vs Sales
print("\nRegression Analysis:")
regression = linear_regression(df, 'MarketingSpend', 'Sales')
print(f"Equation: {regression['equation']}")
print(f"R-squared: {regression['r_squared']:.4f}")
print(f"P-value: {regression['p_value']:.4f}")

# 3. Visualize the regression
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(10, 6))
ax.scatter(df['MarketingSpend'], df['Sales'], alpha=0.5, label='Actual')
ax.plot(df['MarketingSpend'], regression['predictions'], color='red', label='Predicted', linewidth=2)
ax.set_xlabel('Marketing Spend ($)')
ax.set_ylabel('Sales ($)')
ax.set_title(f'Marketing Spend vs Sales\n{regression["equation"]}, R²={regression["r_squared"]:.3f}')
ax.legend()
save_chart(fig, 'marketing_regression.png')
```

### Example 2: A/B Testing Analysis

```python
from statistical_analysis import t_test
from business_analytics import ab_test_analysis

# Load A/B test data
df = read_file('ab_test_results.csv')

# Split into control and treatment groups
control = df[df['Group'] == 'Control']['ConversionRate']
treatment = df[df['Group'] == 'Treatment']['ConversionRate']

# Perform A/B test analysis
results = ab_test_analysis(control, treatment, metric_name='Conversion Rate')

print("A/B Test Results")
print("=" * 60)
print(f"Control Mean: {results['control']['mean']:.4f}")
print(f"Treatment Mean: {results['treatment']['mean']:.4f}")
print(f"Lift: {results['difference']['lift_percentage']:.2f}%")
print(f"P-value: {results['statistical_test']['p_value']:.4f}")
print(f"Significant: {results['statistical_test']['significant']}")
print(f"Recommendation: {results['recommendation']}")
```

### Example 3: ANOVA Test for Multiple Groups

```python
from statistical_analysis import anova_test

# Load regional performance data
df = read_file('regional_sales.xlsx')

# Test if sales differ significantly across regions
anova_results = anova_test(df, value_col='Sales', group_col='Region')

print("ANOVA Test Results")
print("=" * 60)
print(f"F-statistic: {anova_results['f_statistic']:.4f}")
print(f"P-value: {anova_results['p_value']:.4f}")
print(f"\n{anova_results['interpretation']}")
print("\nGroup Statistics:")
print(anova_results['group_statistics'])
```

### Example 4: Outlier Detection

```python
from statistical_analysis import outlier_detection
from visualization import create_chart

# Detect outliers in sales data
df = read_file('daily_sales.csv')

outliers_iqr = outlier_detection(df['Sales'], method='iqr', threshold=1.5)
outliers_zscore = outlier_detection(df['Sales'], method='zscore', threshold=3)

print(f"IQR Method: {outliers_iqr['n_outliers']} outliers ({outliers_iqr['outlier_percentage']:.2f}%)")
print(f"Z-score Method: {outliers_zscore['n_outliers']} outliers ({outliers_zscore['outlier_percentage']:.2f}%)")

# Visualize with box plot
fig = create_chart(df, 'box', y='Sales', title='Sales Distribution with Outliers')
save_chart(fig, 'outliers_boxplot.png')
```

## Data Quality & Profiling Examples

### Example 5: Comprehensive Data Quality Report

```python
from data_profiling import (
    profile_dataset,
    data_quality_score,
    generate_data_quality_report,
    recommend_fixes
)

# Load customer data
df = read_file('customer_data.csv')

# Generate quality score
quality = data_quality_score(df)
print(f"Overall Quality Score: {quality['overall_score']}/100 - {quality['grade']}")
print(f"Completeness: {quality['completeness']:.1f}%")
print(f"Uniqueness: {quality['uniqueness']:.1f}%")
print(f"Consistency: {quality['consistency']:.1f}%")

# Generate detailed report
report = generate_data_quality_report(df)
print("\n" + report)

# Get automated fix recommendations
recommendations = recommend_fixes(df)
print("\nRecommended Fixes:")
for i, rec in enumerate(recommendations, 1):
    print(f"{i}. {rec['column']}: {rec['recommendation']}")
    print(f"   Action: {rec['action']}\n")
```

### Example 6: Column Profiling

```python
from data_profiling import profile_column

# Profile a specific column
column_profile = profile_column(df, 'Email')

print(f"Type: {column_profile['type']}")
print(f"Missing: {column_profile['missing_count']} ({column_profile['missing_percentage']:.1f}%)")
print(f"Unique Values: {column_profile['unique_count']}")
print(f"Empty Strings: {column_profile.get('empty_strings', 0)}")
print("\nTop Values:")
for value, count in list(column_profile['top_values'].items())[:5]:
    print(f"  {value}: {count}")
```

### Example 7: Dataset Comparison

```python
from data_profiling import compare_datasets

# Compare two versions of a dataset
df_old = read_file('customer_data_2023.csv')
df_new = read_file('customer_data_2024.csv')

comparison = compare_datasets(df_old, df_new)

print("Dataset Comparison")
print("=" * 60)
print(f"Old shape: {comparison['shape_comparison']['df1_shape']}")
print(f"New shape: {comparison['shape_comparison']['df2_shape']}")
print(f"\nColumns only in old: {comparison['column_comparison']['df1_only']}")
print(f"Columns only in new: {comparison['column_comparison']['df2_only']}")
print(f"\nData type differences: {comparison['data_type_differences']}")
```

## Business Analytics Examples

### Example 8: RFM Analysis and Customer Segmentation

```python
from business_analytics import rfm_analysis
from visualization import create_chart
from excel_utils import save_to_excel

# Load transaction data
df = read_file('transactions.csv')

# Perform RFM analysis
rfm = rfm_analysis(df, customer_col='CustomerID', date_col='Date', revenue_col='Amount')

print("RFM Analysis Results")
print("=" * 60)
print(rfm.head())

# Segment distribution
print("\nCustomer Segments:")
print(rfm['Segment'].value_counts())

# Visualize segments
segment_summary = rfm.groupby('Segment').agg({
    'Monetary': 'sum',
    'CustomerID': 'count'
}).reset_index()
segment_summary.columns = ['Segment', 'Total_Revenue', 'Customer_Count']

fig = create_chart(segment_summary, 'bar', x='Segment', y='Total_Revenue',
                  title='Revenue by Customer Segment')
save_chart(fig, 'rfm_segments.png')

# Save detailed results
save_to_excel(rfm, 'rfm_analysis.xlsx')
```

### Example 9: Customer Lifetime Value (CLV)

```python
from business_analytics import customer_lifetime_value

# Calculate CLV
clv = customer_lifetime_value(df, customer_col='CustomerID',
                               revenue_col='Amount', date_col='Date',
                               discount_rate=0.1)

print("Customer Lifetime Value Analysis")
print("=" * 60)
print(clv.nlargest(10, 'clv_3yr')[['CustomerID', 'clv_3yr', 'value_tier']])

# Analyze by tier
tier_summary = clv.groupby('value_tier').agg({
    'clv_3yr': ['mean', 'sum', 'count'],
    'total_revenue': 'mean',
    'purchase_count': 'mean'
})
print("\nValue Tier Summary:")
print(tier_summary)
```

### Example 10: Cohort Retention Analysis

```python
from business_analytics import cohort_analysis
from visualization import create_chart

# Perform cohort analysis
cohort_retention = cohort_analysis(df, customer_col='CustomerID',
                                   date_col='Date', metric_col='Amount',
                                   period='M')

print("Cohort Retention Rates (%):")
print(cohort_retention.head())

# Visualize cohort heatmap
fig = create_chart(cohort_retention, 'heatmap',
                  title='Customer Retention by Cohort (%)',
                  figsize=(14, 10))
save_chart(fig, 'cohort_retention.png')
```

### Example 11: Funnel Analysis

```python
from business_analytics import funnel_analysis
from visualization import create_chart

# Analyze conversion funnel
funnel_df = read_file('user_journey.csv')

stages = ['Landing', 'Product View', 'Add to Cart', 'Checkout', 'Purchase']
funnel_results = funnel_analysis(funnel_df, stages=stages,
                                user_col='UserID', stage_col='Stage')

print("Conversion Funnel Analysis")
print("=" * 60)
print(funnel_results)

# Visualize funnel
fig, ax = plt.subplots(figsize=(10, 6))
ax.barh(funnel_results['Stage'], funnel_results['Users'])
ax.set_xlabel('Number of Users')
ax.set_title('Conversion Funnel')

# Add conversion rates
for i, row in funnel_results.iterrows():
    ax.text(row['Users'], i, f" {row['Conversion from Previous (%)']:.1f}%",
           va='center')

save_chart(fig, 'conversion_funnel.png')
```

### Example 12: Market Basket Analysis

```python
from business_analytics import market_basket_analysis

# Find product associations
df = read_file('transactions.csv')

rules = market_basket_analysis(df, transaction_col='OrderID',
                               product_col='Product', min_support=0.01)

print("Product Association Rules")
print("=" * 60)
print("Top 10 rules by lift:")
print(rules.nlargest(10, 'lift')[['antecedents', 'consequents', 'support',
                                   'confidence', 'lift']])
```

## Forecasting & Time Series Examples

### Example 13: Time Series Decomposition

```python
from forecasting import decompose_time_series, detect_seasonality
from visualization import create_multi_chart

# Load time series data
df = read_file('daily_sales.csv')
df['Date'] = pd.to_datetime(df['Date'])
ts_data = df.set_index('Date')['Sales']

# Detect seasonality
seasonality = detect_seasonality(ts_data)
print(f"Seasonal: {seasonality['is_seasonal']}")
print(f"Period: {seasonality['period']}")

# Decompose time series
decomp = decompose_time_series(ts_data, period=7, model='additive')

# Visualize components
import pandas as pd
decomp_df = pd.DataFrame({
    'Date': decomp['observed'].index,
    'Observed': decomp['observed'].values,
    'Trend': decomp['trend'].values,
    'Seasonal': decomp['seasonal'].values,
    'Residual': decomp['residual'].values
})

charts_config = [
    {'chart_type': 'line', 'x': 'Date', 'y': 'Observed', 'title': 'Observed'},
    {'chart_type': 'line', 'x': 'Date', 'y': 'Trend', 'title': 'Trend'},
    {'chart_type': 'line', 'x': 'Date', 'y': 'Seasonal', 'title': 'Seasonal'},
    {'chart_type': 'line', 'x': 'Date', 'y': 'Residual', 'title': 'Residual'}
]

decomp_df['Date'] = decomp_df['Date'].astype(str)
fig = create_multi_chart(decomp_df, charts_config, layout=(4, 1),
                        figsize=(12, 12), suptitle='Time Series Decomposition')
save_chart(fig, 'decomposition.png')
```

### Example 14: Sales Forecasting

```python
from forecasting import predict_next_values, moving_average_forecast
from visualization import create_time_series_plot

# Forecast next 30 days
forecast = predict_next_values(ts_data, method='auto', periods=30)

print(f"Forecast Method: {forecast['method']}")
print(f"Last Actual Value: {forecast['last_value']:.2f}")
print(f"Forecast Mean: {forecast['forecast_mean']:.2f}")

# Combine historical and forecast
historical_df = pd.DataFrame({'Date': ts_data.index, 'Sales': ts_data.values})
forecast_df = pd.DataFrame({
    'Date': forecast['forecast'].index,
    'Sales': forecast['forecast'].values
})

combined = pd.concat([historical_df, forecast_df])

# Visualize
fig = create_time_series_plot(historical_df, 'Date', 'Sales',
                              title='Sales Forecast (Next 30 Days)',
                              rolling_window=7)
save_chart(fig, 'sales_forecast.png')
```

### Example 15: Anomaly Detection

```python
from forecasting import detect_anomalies

# Detect anomalies in time series
anomalies = detect_anomalies(ts_data, method='iqr', threshold=1.5)

print(f"Anomalies Detected: {anomalies['n_anomalies']}")
print(f"Percentage: {anomalies['anomaly_percentage']:.2f}%")
print(f"\nAnomaly Dates:")
for date, value in zip(anomalies['anomaly_indices'][:10],
                       anomalies['anomaly_values'][:10]):
    print(f"  {date}: {value:.2f}")

# Visualize anomalies
fig, ax = plt.subplots(figsize=(14, 6))
ax.plot(ts_data.index, ts_data.values, label='Sales')
ax.scatter(anomalies['anomaly_indices'], anomalies['anomaly_values'],
          color='red', s=50, label='Anomalies', zorder=5)
ax.axhline(y=anomalies['upper_bound'], color='r', linestyle='--',
          alpha=0.5, label='Upper Bound')
ax.axhline(y=anomalies['lower_bound'], color='r', linestyle='--',
          alpha=0.5, label='Lower Bound')
ax.set_title('Sales with Anomaly Detection')
ax.legend()
save_chart(fig, 'anomalies.png')
```

### Example 16: Year-over-Year Growth Analysis

```python
from forecasting import year_over_year_comparison, calculate_growth_rate

# YoY comparison
yoy = year_over_year_comparison(df, date_col='Date', value_col='Sales', period='M')

print("Year-over-Year Comparison")
print("=" * 60)
print(yoy)

# Monthly growth rates
growth = calculate_growth_rate(df, date_col='Date', value_col='Sales', period='M')

print("\nMonthly Growth Rates")
print("=" * 60)
print(growth[['period', 'Sales', 'growth_rate', 'cumulative_growth']].tail(12))
```

## Combined Advanced Analysis Example

### Example 17: Complete Customer Analytics Dashboard

```python
# Comprehensive customer analytics combining multiple techniques

# 1. Load and profile data
df = read_file('customer_transactions.csv')

# Data quality check
quality = data_quality_score(df)
print(f"Data Quality Score: {quality['overall_score']}/100")

# 2. RFM Analysis
rfm = rfm_analysis(df, 'CustomerID', 'Date', 'Amount')

# 3. CLV Calculation
clv = customer_lifetime_value(df, 'CustomerID', 'Amount', 'Date')

# 4. Cohort Analysis
cohort = cohort_analysis(df, 'CustomerID', 'Date', 'Amount', period='M')

# 5. Churn Risk Assessment
from business_analytics import churn_prediction_features
churn_features = churn_prediction_features(df, 'CustomerID', 'Date', 'Amount')

# 6. Time Series Forecasting
daily_revenue = df.groupby('Date')['Amount'].sum().sort_index()
forecast = predict_next_values(daily_revenue, method='auto', periods=30)

# 7. Create comprehensive report
report_data = {
    'RFM_Analysis': rfm,
    'Customer_Lifetime_Value': clv,
    'Cohort_Retention': cohort,
    'Churn_Risk': churn_features,
    'Revenue_Forecast': pd.DataFrame({
        'Date': forecast['forecast'].index,
        'Predicted_Revenue': forecast['forecast'].values
    })
}

save_to_excel(report_data, 'customer_analytics_dashboard.xlsx', auto_format=True)

# 8. Create visualizations dashboard
charts_config = [
    # RFM segment distribution
    {'chart_type': 'pie', 'x': 'Segment', 'y': 'CustomerID',
     'title': 'Customer Segments'},
    # CLV by tier
    {'chart_type': 'bar', 'x': 'value_tier', 'y': 'clv_3yr',
     'title': 'Average CLV by Tier'},
    # Churn risk distribution
    {'chart_type': 'pie', 'x': 'churn_risk', 'y': 'CustomerID',
     'title': 'Churn Risk Distribution'},
]

print("Customer Analytics Dashboard complete!")
print(f"Report saved to: customer_analytics_dashboard.xlsx")
```

## Tips for Advanced Analytics

1. **Data Quality First**: Always run data quality checks before analysis
2. **Visualize Everything**: Create charts for all major findings
3. **Statistical Significance**: Check p-values before making business decisions
4. **Document Assumptions**: Note any data cleaning or assumptions made
5. **Validate Results**: Cross-check results with business knowledge
6. **Iterate**: Refine analysis based on initial findings
7. **Combine Techniques**: Use multiple methods for comprehensive insights
8. **Monitor Performance**: Track forecast accuracy and model performance over time
