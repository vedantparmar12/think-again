# Excel Data Analyzer Skill

A comprehensive Claude skill for analyzing, transforming, and visualizing data from Excel and CSV files. This skill enables Claude to perform enterprise-level data operations including pivot tables, data cleaning, merging, statistical analysis, and chart generation.

## Features

- **File Operations**: Read/write CSV, Excel (single/multi-sheet), TSV files
- **Data Transformation**: Pivot tables, merging, filtering, sorting, reshaping
- **Data Cleaning**: Handle missing values, remove duplicates, standardize formats
- **Analysis**: Aggregations, statistics, time series, cohort analysis
- **Visualization**: Line, bar, scatter, pie, histogram, heatmaps, dashboards
- **Excel Formatting**: Auto-formatting, conditional formatting, formulas, charts
- **Advanced Operations**: Multi-file consolidation, lookup operations, cross-tabulation

## Installation

### 1. Install Required Python Libraries

```bash
pip install -r requirements.txt
```

Or install individually:

```bash
pip install pandas openpyxl matplotlib seaborn numpy xlsxwriter
```

### 2. Verify Installation

```python
python -c "import pandas, openpyxl, matplotlib, seaborn, numpy; print('All dependencies installed successfully!')"
```

## Quick Start

### Using the Skill in Claude Code

Once installed in `~/.codex/skills/` (or `.codex/skills/` in your repo), Claude will automatically detect and load this skill.

**Explicit Invocation:**
```
@excel-data-analyzer Can you create a pivot table from sales.xlsx showing total sales by region and product?
```

**Implicit Invocation:**
Claude will automatically use this skill when you mention tasks like:
- "Analyze this Excel file"
- "Create a pivot table from my data"
- "Merge these two CSV files"
- "Generate a sales chart"

### Example Prompts

1. **Pivot Table**:
   ```
   Create a pivot table from sales_data.xlsx showing total revenue by region and product category
   ```

2. **Data Merging**:
   ```
   Merge customers.xlsx and orders.xlsx on CustomerID and save the result
   ```

3. **Visualization**:
   ```
   Create a dashboard with sales trends, top products, and regional performance from my sales data
   ```

4. **Data Cleaning**:
   ```
   Clean this customer data: remove duplicates, fill missing values, and standardize phone numbers
   ```

5. **Time Series Analysis**:
   ```
   Analyze daily_sales.csv and create a trend chart with 7-day moving average
   ```

## Folder Structure

```
excel-data-analyzer/
├── SKILL.md                    # Main skill instructions for Claude
├── README.md                   # This file
├── requirements.txt            # Python dependencies
├── scripts/                    # Helper Python modules
│   ├── data_operations.py      # Data manipulation functions
│   ├── visualization.py        # Chart generation functions
│   └── excel_utils.py          # Excel-specific utilities
├── references/                 # Documentation
│   ├── quick-start-guide.md    # Getting started guide
│   └── examples.md             # Advanced examples
└── assets/                     # Sample data and templates
    ├── README.md               # Sample data documentation
    └── sample_sales_data.csv   # Practice dataset
```

## Documentation

- **[SKILL.md](SKILL.md)**: Complete skill specification and instructions
- **[Quick Start Guide](references/quick-start-guide.md)**: Basic usage examples
- **[Advanced Examples](references/examples.md)**: Complex real-world scenarios
- **[Sample Data](assets/README.md)**: Practice with sample datasets

## Capabilities

### Data Operations
- Smart file reading (auto-detects CSV, Excel, TSV)
- Pivot table creation with multiple aggregations
- Merge/join operations (inner, outer, left, right)
- Data filtering and sorting
- Aggregations and grouping
- Transpose and reshape operations
- Multi-file concatenation

### Data Cleaning
- Remove duplicates
- Handle missing values (fill, drop, interpolate)
- Data type conversion
- Text operations (clean, extract, split)
- Standardization and normalization
- Data validation

### Visualization
- Line, bar, scatter, pie charts
- Histograms, box plots, heatmaps
- Multi-chart dashboards
- Time series plots with moving averages
- Correlation matrices
- Distribution plots
- Customizable colors, titles, labels

### Excel Features
- Multi-sheet workbooks
- Auto-formatting (headers, borders, widths)
- Conditional formatting (color scales, data bars)
- Excel formulas
- Embedded charts
- Freeze panes, auto-filters
- Summary sheets

## Usage Examples

### Python Scripts

You can use the helper modules directly in your Python scripts:

```python
import sys
sys.path.append('C:/Users/vedan/.codex/skills/excel-data-analyzer/scripts')

from data_operations import read_file, create_pivot
from visualization import create_chart, save_chart
from excel_utils import save_to_excel

# Read data
df = read_file('data.xlsx', sheet_name='Sales')

# Create pivot
pivot = create_pivot(df, index='Region', columns='Product',
                    values='Sales', aggfunc='sum')

# Visualize
fig = create_chart(df, 'bar', x='Product', y='Sales',
                  title='Sales by Product')
save_chart(fig, 'chart.png')

# Save report
save_to_excel({'Data': df, 'Pivot': pivot}, 'report.xlsx')
```

### With Claude Code

Simply ask Claude to perform operations using natural language:

```
Can you:
1. Load sales_2024.xlsx
2. Clean the data (remove duplicates and fill missing values)
3. Create a pivot table showing sales by month and product
4. Generate a line chart showing the trend
5. Save everything to a formatted Excel report
```

Claude will use this skill to execute the operations automatically.

## Sample Data

Practice with the included sample data:

```
C:/Users/vedan/.codex/skills/excel-data-analyzer/assets/sample_sales_data.csv
```

This contains sample sales transactions with:
- Dates, regions, products
- Sales amounts and quantities
- Customer IDs

Perfect for practicing pivot tables, time series, and aggregations.

## Best Practices

1. **Preview data first**: Always examine data structure before operations
2. **Preserve originals**: Create new files, don't overwrite source data
3. **Validate results**: Check row counts and sample data after transformations
4. **Use descriptive names**: Name output files clearly
5. **Handle errors**: Check for missing files, invalid data types
6. **Document assumptions**: Explain business logic in your prompts
7. **Test with samples**: For large files, test on subsets first

## Troubleshooting

### Dependencies Not Found
```bash
pip install -r requirements.txt --upgrade
```

### Import Errors
Ensure the scripts directory is in your Python path:
```python
import sys
sys.path.append('C:/Users/vedan/.codex/skills/excel-data-analyzer/scripts')
```

### File Not Found
Use absolute paths or verify your working directory:
```python
import os
print(os.getcwd())
```

### Memory Issues with Large Files
Read in chunks:
```python
chunks = pd.read_csv('large.csv', chunksize=10000)
for chunk in chunks:
    process(chunk)
```

## Contributing

This skill follows the [Agent Skills specification](https://agentskills.io). To modify:

1. Update `SKILL.md` for instruction changes
2. Modify scripts in `scripts/` for new functionality
3. Add examples to `references/examples.md`
4. Test with sample data in `assets/`

## Support

For issues or questions:
1. Review documentation in `references/`
2. Check examples in `references/examples.md`
3. Try sample data in `assets/`
4. Verify dependencies are installed

## Version

**Version**: 1.0.0
**Author**: Claude Code
**License**: MIT

## Tags

`data-analysis` `excel` `csv` `visualization` `pivot-tables` `charts` `business-analytics` `pandas` `matplotlib`
