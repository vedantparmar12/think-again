"""
Data Operations Module for Excel/CSV Analysis
Provides core data manipulation functions for the excel-data-analyzer skill
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Union, List, Optional, Dict, Any


def read_file(
    file_path: Union[str, Path],
    sheet_name: Optional[Union[str, int, List]] = 0,
    **kwargs
) -> Union[pd.DataFrame, Dict[str, pd.DataFrame]]:
    """
    Smart file reader that automatically detects file type and loads data.

    Args:
        file_path: Path to the file (CSV, Excel, TSV, etc.)
        sheet_name: For Excel files - sheet name, index, or list of sheets
                   None loads all sheets as dict
        **kwargs: Additional arguments passed to pandas read functions

    Returns:
        DataFrame or dict of DataFrames

    Examples:
        >>> df = read_file('data.csv')
        >>> df = read_file('data.xlsx', sheet_name='Sales')
        >>> dfs = read_file('data.xlsx', sheet_name=None)  # All sheets
    """
    file_path = Path(file_path)

    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    suffix = file_path.suffix.lower()

    # Excel files
    if suffix in ['.xlsx', '.xls', '.xlsm']:
        return pd.read_excel(file_path, sheet_name=sheet_name, **kwargs)

    # CSV files
    elif suffix == '.csv':
        # Try to auto-detect delimiter
        if 'sep' not in kwargs and 'delimiter' not in kwargs:
            with open(file_path, 'r', encoding='utf-8') as f:
                first_line = f.readline()
                if '\t' in first_line:
                    kwargs['sep'] = '\t'
                elif ';' in first_line:
                    kwargs['sep'] = ';'
        return pd.read_csv(file_path, **kwargs)

    # TSV files
    elif suffix in ['.tsv', '.tab']:
        return pd.read_csv(file_path, sep='\t', **kwargs)

    # Text files
    elif suffix == '.txt':
        return pd.read_csv(file_path, **kwargs)

    else:
        raise ValueError(f"Unsupported file type: {suffix}")


def create_pivot(
    df: pd.DataFrame,
    index: Union[str, List[str]],
    columns: Optional[Union[str, List[str]]] = None,
    values: Optional[Union[str, List[str]]] = None,
    aggfunc: Union[str, List, Dict] = 'sum',
    fill_value: Any = None,
    margins: bool = False,
    margins_name: str = 'Total'
) -> pd.DataFrame:
    """
    Create a pivot table from DataFrame.

    Args:
        df: Source DataFrame
        index: Column(s) to use as row index
        columns: Column(s) to use as column headers
        values: Column(s) to aggregate
        aggfunc: Aggregation function(s) - 'sum', 'mean', 'count', etc.
        fill_value: Value to replace missing values
        margins: Add row/column totals
        margins_name: Name for the total row/column

    Returns:
        Pivot table DataFrame

    Examples:
        >>> pivot = create_pivot(df, index='Region', columns='Product',
        ...                      values='Sales', aggfunc='sum')
        >>> pivot = create_pivot(df, index=['Year', 'Quarter'],
        ...                      values='Revenue', aggfunc=['sum', 'mean'])
    """
    return pd.pivot_table(
        df,
        index=index,
        columns=columns,
        values=values,
        aggfunc=aggfunc,
        fill_value=fill_value,
        margins=margins,
        margins_name=margins_name
    )


def merge_sheets(
    source1: Union[str, Path, pd.DataFrame],
    source2: Union[str, Path, pd.DataFrame],
    on: Optional[Union[str, List[str]]] = None,
    how: str = 'inner',
    left_on: Optional[Union[str, List[str]]] = None,
    right_on: Optional[Union[str, List[str]]] = None,
    suffixes: tuple = ('_left', '_right'),
    sheet1: Optional[str] = None,
    sheet2: Optional[str] = None,
    validate: Optional[str] = None
) -> pd.DataFrame:
    """
    Merge two data sources (files or DataFrames).

    Args:
        source1: First data source (file path or DataFrame)
        source2: Second data source (file path or DataFrame)
        on: Column(s) to join on (if same in both)
        how: Join type - 'inner', 'outer', 'left', 'right'
        left_on: Column(s) from left DataFrame to join on
        right_on: Column(s) from right DataFrame to join on
        suffixes: Suffixes for overlapping column names
        sheet1: Sheet name if source1 is Excel file
        sheet2: Sheet name if source2 is Excel file
        validate: Validate join type ('one_to_one', 'one_to_many', etc.)

    Returns:
        Merged DataFrame

    Examples:
        >>> merged = merge_sheets('sales.xlsx', 'customers.xlsx',
        ...                       on='CustomerID', how='left')
        >>> merged = merge_sheets(df1, df2, left_on='ID', right_on='CustID')
    """
    # Load data if file paths provided
    if isinstance(source1, (str, Path)):
        df1 = read_file(source1, sheet_name=sheet1 or 0)
    else:
        df1 = source1

    if isinstance(source2, (str, Path)):
        df2 = read_file(source2, sheet_name=sheet2 or 0)
    else:
        df2 = source2

    # Perform merge
    return pd.merge(
        df1, df2,
        on=on,
        how=how,
        left_on=left_on,
        right_on=right_on,
        suffixes=suffixes,
        validate=validate
    )


def clean_data(
    df: pd.DataFrame,
    strategy: str = 'basic',
    custom_config: Optional[Dict] = None
) -> pd.DataFrame:
    """
    Clean DataFrame using various strategies.

    Args:
        df: DataFrame to clean
        strategy: Cleaning strategy - 'basic', 'aggressive', 'custom'
        custom_config: Custom cleaning configuration dict

    Returns:
        Cleaned DataFrame

    Strategies:
        - basic: Remove duplicates, strip whitespace, standardize column names
        - aggressive: Basic + fill/drop missing values, convert data types
        - custom: Use custom_config dict to specify operations

    Examples:
        >>> clean_df = clean_data(df, strategy='basic')
        >>> clean_df = clean_data(df, strategy='custom',
        ...                       custom_config={'drop_na': True, 'fill_value': 0})
    """
    df_clean = df.copy()

    if strategy == 'basic' or strategy == 'aggressive':
        # Remove duplicate rows
        df_clean = df_clean.drop_duplicates()

        # Strip whitespace from string columns
        string_cols = df_clean.select_dtypes(include=['object']).columns
        for col in string_cols:
            df_clean[col] = df_clean[col].str.strip() if df_clean[col].dtype == 'object' else df_clean[col]

        # Standardize column names
        df_clean.columns = df_clean.columns.str.strip().str.lower().str.replace(' ', '_')

    if strategy == 'aggressive':
        # Fill numeric missing values with median
        numeric_cols = df_clean.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            df_clean[col] = df_clean[col].fillna(df_clean[col].median())

        # Fill string missing values with 'Unknown'
        string_cols = df_clean.select_dtypes(include=['object']).columns
        for col in string_cols:
            df_clean[col] = df_clean[col].fillna('Unknown')

    if strategy == 'custom' and custom_config:
        if custom_config.get('drop_na'):
            df_clean = df_clean.dropna()

        if 'fill_value' in custom_config:
            df_clean = df_clean.fillna(custom_config['fill_value'])

        if 'drop_columns' in custom_config:
            df_clean = df_clean.drop(columns=custom_config['drop_columns'], errors='ignore')

        if 'rename_columns' in custom_config:
            df_clean = df_clean.rename(columns=custom_config['rename_columns'])

    return df_clean


def filter_data(
    df: pd.DataFrame,
    conditions: Union[str, List[str], pd.Series],
    **kwargs
) -> pd.DataFrame:
    """
    Filter DataFrame based on conditions.

    Args:
        df: DataFrame to filter
        conditions: Filter condition(s) - query string, list of queries, or boolean Series
        **kwargs: Additional keyword arguments

    Returns:
        Filtered DataFrame

    Examples:
        >>> filtered = filter_data(df, "Age > 25 and City == 'New York'")
        >>> filtered = filter_data(df, ["Sales > 1000", "Region == 'East'"])
        >>> filtered = filter_data(df, df['Status'] == 'Active')
    """
    if isinstance(conditions, str):
        return df.query(conditions)
    elif isinstance(conditions, list):
        result = df
        for condition in conditions:
            result = result.query(condition)
        return result
    elif isinstance(conditions, pd.Series):
        return df[conditions]
    else:
        raise ValueError("Conditions must be string, list of strings, or boolean Series")


def aggregate_data(
    df: pd.DataFrame,
    group_by: Union[str, List[str]],
    agg_config: Dict[str, Union[str, List[str]]],
    sort: bool = True,
    sort_by: Optional[str] = None,
    ascending: bool = False
) -> pd.DataFrame:
    """
    Group and aggregate data.

    Args:
        df: DataFrame to aggregate
        group_by: Column(s) to group by
        agg_config: Dict mapping columns to aggregation functions
        sort: Whether to sort results
        sort_by: Column to sort by (defaults to first aggregation)
        ascending: Sort order

    Returns:
        Aggregated DataFrame

    Examples:
        >>> agg = aggregate_data(df, group_by='Category',
        ...                      agg_config={'Sales': 'sum', 'Quantity': 'mean'})
        >>> agg = aggregate_data(df, group_by=['Region', 'Product'],
        ...                      agg_config={'Revenue': ['sum', 'mean', 'count']})
    """
    result = df.groupby(group_by).agg(agg_config).reset_index()

    if sort:
        if sort_by:
            result = result.sort_values(sort_by, ascending=ascending)
        else:
            # Sort by first aggregated column
            first_agg_col = result.columns[len(group_by) if isinstance(group_by, list) else 1]
            result = result.sort_values(first_agg_col, ascending=ascending)

    return result


def transpose_data(
    df: pd.DataFrame,
    index_col: Optional[str] = None,
    reset_index: bool = True
) -> pd.DataFrame:
    """
    Transpose DataFrame (swap rows and columns).

    Args:
        df: DataFrame to transpose
        index_col: Column to use as index before transposing
        reset_index: Whether to reset index after transposing

    Returns:
        Transposed DataFrame
    """
    if index_col:
        df = df.set_index(index_col)

    transposed = df.T

    if reset_index:
        transposed = transposed.reset_index()

    return transposed


def concatenate_files(
    file_paths: List[Union[str, Path]],
    axis: int = 0,
    ignore_index: bool = True,
    keys: Optional[List[str]] = None,
    **kwargs
) -> pd.DataFrame:
    """
    Concatenate multiple files into a single DataFrame.

    Args:
        file_paths: List of file paths to concatenate
        axis: Axis to concatenate along (0=rows, 1=columns)
        ignore_index: Whether to reset index
        keys: Labels for source files in result
        **kwargs: Additional arguments for read_file

    Returns:
        Concatenated DataFrame

    Examples:
        >>> combined = concatenate_files(['jan.csv', 'feb.csv', 'mar.csv'])
        >>> combined = concatenate_files(['sales.xlsx', 'returns.xlsx'],
        ...                              keys=['Sales', 'Returns'])
    """
    dfs = [read_file(fp, **kwargs) for fp in file_paths]
    return pd.concat(dfs, axis=axis, ignore_index=ignore_index, keys=keys)


def get_summary_stats(df: pd.DataFrame, include_all: bool = False) -> pd.DataFrame:
    """
    Get summary statistics for DataFrame.

    Args:
        df: DataFrame to summarize
        include_all: Include statistics for non-numeric columns

    Returns:
        DataFrame with summary statistics
    """
    if include_all:
        return df.describe(include='all')
    else:
        return df.describe()


if __name__ == "__main__":
    # Example usage
    print("Data Operations Module - Example Usage")
    print("=" * 50)

    # Create sample data
    sample_data = pd.DataFrame({
        'Region': ['East', 'West', 'East', 'West', 'East'],
        'Product': ['A', 'B', 'A', 'B', 'A'],
        'Sales': [100, 200, 150, 250, 120],
        'Quantity': [10, 20, 15, 25, 12]
    })

    print("\nSample Data:")
    print(sample_data)

    print("\nPivot Table (Sales by Region and Product):")
    pivot = create_pivot(sample_data, index='Region', columns='Product',
                        values='Sales', aggfunc='sum', fill_value=0)
    print(pivot)

    print("\nAggregate by Region:")
    agg = aggregate_data(sample_data, group_by='Region',
                        agg_config={'Sales': 'sum', 'Quantity': 'mean'})
    print(agg)
