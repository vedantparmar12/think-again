# Excel Data Analyzer - Advanced Examples

## Example 1: Comprehensive Sales Analysis Dashboard

### Scenario
You have sales data with transactions and need to create a comprehensive dashboard showing:
- Sales trends over time
- Top performing products
- Regional performance
- Customer segmentation

### Solution

```python
import pandas as pd
import sys
sys.path.append('C:/Users/vedan/.codex/skills/excel-data-analyzer/scripts')
from data_operations import read_file, create_pivot, aggregate_data
from visualization import create_multi_chart, save_chart
from excel_utils import save_to_excel, add_summary_sheet

# 1. Load and prepare data
df = read_file('sales_data.xlsx')
df['Date'] = pd.to_datetime(df['Date'])
df['Month'] = df['Date'].dt.to_period('M')

# 2. Create various analyses
# Monthly trend
monthly_sales = aggregate_data(
    df,
    group_by='Month',
    agg_config={'Sales': 'sum', 'Quantity': 'sum'}
)

# Product performance
product_sales = aggregate_data(
    df,
    group_by='Product',
    agg_config={'Sales': 'sum', 'Quantity': 'sum'},
    sort_by='Sales',
    ascending=False
)

# Regional breakdown
regional_pivot = create_pivot(
    df,
    index='Region',
    columns='Product',
    values='Sales',
    aggfunc='sum',
    margins=True
)

# Customer segmentation
customer_stats = aggregate_data(
    df,
    group_by='CustomerID',
    agg_config={'Sales': ['sum', 'mean', 'count']}
)

# 3. Create dashboard
charts_config = [
    {
        'chart_type': 'line',
        'x': 'Month',
        'y': 'Sales',
        'title': 'Monthly Sales Trend'
    },
    {
        'chart_type': 'bar',
        'x': 'Product',
        'y': 'Sales',
        'title': 'Sales by Product'
    },
    {
        'chart_type': 'bar',
        'x': 'Region',
        'y': 'Sales',
        'title': 'Sales by Region'
    },
    {
        'chart_type': 'histogram',
        'y': 'Sales',
        'title': 'Sales Distribution',
        'bins': 30
    }
]

# Convert Month to string for plotting
monthly_sales['Month'] = monthly_sales['Month'].astype(str)

fig = create_multi_chart(df, charts_config, layout=(2, 2),
                        suptitle='Sales Dashboard - Q4 2024')
save_chart(fig, 'sales_dashboard.png')

# 4. Save comprehensive report
report_data = {
    'Raw Data': df,
    'Monthly Summary': monthly_sales,
    'Product Performance': product_sales,
    'Regional Pivot': regional_pivot,
    'Customer Stats': customer_stats
}

output_file = save_to_excel(report_data, 'sales_analysis_report.xlsx')

# 5. Add executive summary
summary = {
    'Total Sales': f"${df['Sales'].sum():,.2f}",
    'Total Transactions': len(df),
    'Average Order Value': f"${df['Sales'].mean():,.2f}",
    'Top Product': product_sales.iloc[0]['Product'],
    'Best Region': df.groupby('Region')['Sales'].sum().idxmax(),
    'Analysis Period': f"{df['Date'].min()} to {df['Date'].max()}"
}

add_summary_sheet(output_file, summary)

print(f"Analysis complete! Report saved to: {output_file}")
```

## Example 2: Multi-File Consolidation and Analysis

### Scenario
Consolidate quarterly sales files from different regions and create a unified report.

### Solution

```python
from data_operations import concatenate_files, clean_data, create_pivot
from excel_utils import save_to_excel

# 1. Consolidate files
regional_files = [
    'sales_east.xlsx',
    'sales_west.xlsx',
    'sales_north.xlsx',
    'sales_south.xlsx'
]

# Add region identifier
all_data = []
regions = ['East', 'West', 'North', 'South']

for file, region in zip(regional_files, regions):
    df = read_file(file)
    df['Region'] = region
    all_data.append(df)

consolidated = pd.concat(all_data, ignore_index=True)

# 2. Clean consolidated data
consolidated = clean_data(consolidated, strategy='aggressive')

# 3. Create multi-dimensional pivot
pivot = create_pivot(
    consolidated,
    index=['Region', 'Product'],
    columns='Quarter',
    values='Sales',
    aggfunc='sum',
    margins=True
)

# 4. Year-over-year comparison
yoy_pivot = create_pivot(
    consolidated,
    index='Product',
    columns='Year',
    values='Sales',
    aggfunc='sum'
)

# Calculate YoY growth
yoy_pivot['Growth %'] = (
    (yoy_pivot[2024] - yoy_pivot[2023]) / yoy_pivot[2023] * 100
)

# 5. Save comprehensive report
report = {
    'Consolidated Data': consolidated,
    'Regional Pivot': pivot,
    'YoY Comparison': yoy_pivot
}

save_to_excel(report, 'consolidated_report.xlsx')
```

## Example 3: Advanced Data Cleaning and Validation

### Scenario
Clean messy customer data with inconsistencies, duplicates, and missing values.

### Solution

```python
from data_operations import read_file, clean_data

# 1. Read data
df = read_file('customer_data.csv')

print("Before cleaning:")
print(f"Total rows: {len(df)}")
print(f"Duplicates: {df.duplicated().sum()}")
print(f"Missing values:\n{df.isnull().sum()}")

# 2. Custom cleaning
clean_df = clean_data(
    df,
    strategy='custom',
    custom_config={
        'drop_columns': ['Temp', 'Notes'],
        'rename_columns': {
            'Cust_ID': 'CustomerID',
            'Cust_Name': 'CustomerName'
        }
    }
)

# 3. Additional cleaning steps
# Standardize phone numbers
clean_df['Phone'] = clean_df['Phone'].str.replace(r'[^0-9]', '', regex=True)

# Standardize email addresses
clean_df['Email'] = clean_df['Email'].str.lower().str.strip()

# Fix capitalization in names
clean_df['CustomerName'] = clean_df['CustomerName'].str.title()

# 4. Remove duplicates based on email
clean_df = clean_df.drop_duplicates(subset=['Email'], keep='first')

# 5. Fill missing values intelligently
# Fill missing cities with 'Unknown'
clean_df['City'] = clean_df['City'].fillna('Unknown')

# Fill missing ages with median
median_age = clean_df['Age'].median()
clean_df['Age'] = clean_df['Age'].fillna(median_age)

# 6. Validate data
# Check for invalid ages
invalid_ages = clean_df[(clean_df['Age'] < 0) | (clean_df['Age'] > 120)]
if len(invalid_ages) > 0:
    print(f"Warning: {len(invalid_ages)} records with invalid ages")

# Check for invalid emails
invalid_emails = clean_df[~clean_df['Email'].str.contains('@', na=False)]
if len(invalid_emails) > 0:
    print(f"Warning: {len(invalid_emails)} records with invalid emails")

print("\nAfter cleaning:")
print(f"Total rows: {len(clean_df)}")
print(f"Duplicates: {clean_df.duplicated().sum()}")
print(f"Missing values:\n{clean_df.isnull().sum()}")

# 7. Save cleaned data
save_to_excel(clean_df, 'cleaned_customer_data.xlsx')
```

## Example 4: Complex Multi-Sheet Excel Report with Formulas

### Scenario
Create an Excel report with multiple related sheets and Excel formulas.

### Solution

```python
import openpyxl
from excel_utils import save_to_excel, add_summary_sheet
from data_operations import aggregate_data

# 1. Prepare data
sales_df = read_file('sales.xlsx')
costs_df = read_file('costs.xlsx')

# 2. Create analysis sheets
# Monthly summary
monthly = aggregate_data(
    sales_df,
    group_by='Month',
    agg_config={'Sales': 'sum', 'Quantity': 'sum'}
)

# Product profitability
profit_df = pd.merge(
    sales_df.groupby('Product')['Sales'].sum().reset_index(),
    costs_df.groupby('Product')['Cost'].sum().reset_index(),
    on='Product'
)

# 3. Save to Excel
report_data = {
    'Raw Sales': sales_df,
    'Raw Costs': costs_df,
    'Monthly Summary': monthly,
    'Product Analysis': profit_df
}

output_file = save_to_excel(report_data, 'financial_report.xlsx', auto_format=True)

# 4. Add formulas to Product Analysis sheet
workbook = openpyxl.load_workbook(output_file)
worksheet = workbook['Product Analysis']

# Add header for calculated columns
worksheet['D1'] = 'Profit'
worksheet['E1'] = 'Margin %'

# Add formulas
for row in range(2, len(profit_df) + 2):
    # Profit = Sales - Cost
    worksheet[f'D{row}'] = f'=B{row}-C{row}'
    # Margin = Profit / Sales * 100
    worksheet[f'E{row}'] = f'=D{row}/B{row}*100'

# Format the cells
from openpyxl.styles import Font, numbers

for row in range(2, len(profit_df) + 2):
    # Currency format for Sales, Cost, Profit
    worksheet[f'B{row}'].number_format = '$#,##0.00'
    worksheet[f'C{row}'].number_format = '$#,##0.00'
    worksheet[f'D{row}'].number_format = '$#,##0.00'
    # Percentage format for Margin
    worksheet[f'E{row}'].number_format = '0.00%'

# Add conditional formatting for margins
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import PatternFill

# Green for margins > 20%
green_fill = PatternFill(start_color='00FF00', end_color='00FF00', fill_type='solid')
worksheet.conditional_formatting.add(
    f'E2:E{len(profit_df)+1}',
    CellIsRule(operator='greaterThan', formula=['0.2'], fill=green_fill)
)

# Red for margins < 10%
red_fill = PatternFill(start_color='FF0000', end_color='FF0000', fill_type='solid')
worksheet.conditional_formatting.add(
    f'E2:E{len(profit_df)+1}',
    CellIsRule(operator='lessThan', formula=['0.1'], fill=red_fill)
)

workbook.save(output_file)

# 5. Add executive summary
summary = {
    'Total Revenue': f"${sales_df['Sales'].sum():,.2f}",
    'Total Cost': f"${costs_df['Cost'].sum():,.2f}",
    'Overall Profit': f"${sales_df['Sales'].sum() - costs_df['Cost'].sum():,.2f}",
    'Average Margin': f"{((sales_df['Sales'].sum() - costs_df['Cost'].sum()) / sales_df['Sales'].sum() * 100):.2f}%"
}

add_summary_sheet(output_file, summary)

print(f"Report complete: {output_file}")
```

## Example 5: Time Series Analysis with Forecasting

### Scenario
Analyze historical sales data and visualize trends with moving averages.

### Solution

```python
from visualization import create_time_series_plot, create_chart, save_chart
import numpy as np

# 1. Load time series data
df = read_file('daily_sales.csv')
df['Date'] = pd.to_datetime(df['Date'])
df = df.sort_values('Date')

# 2. Calculate moving averages
df['MA_7'] = df['Sales'].rolling(window=7).mean()
df['MA_30'] = df['Sales'].rolling(window=30).mean()

# 3. Calculate growth rate
df['Growth_Rate'] = df['Sales'].pct_change() * 100

# 4. Identify trends
df['Trend'] = np.where(df['MA_7'] > df['MA_30'], 'Upward', 'Downward')

# 5. Create comprehensive time series visualization
fig = create_time_series_plot(
    df,
    date_column='Date',
    value_columns='Sales',
    title='Sales Trend with Moving Averages',
    rolling_window=7,
    figsize=(14, 8)
)
save_chart(fig, 'sales_trend.png')

# 6. Create multi-chart analysis
from visualization import create_multi_chart

charts_config = [
    {
        'chart_type': 'line',
        'x': 'Date',
        'y': ['Sales', 'MA_7', 'MA_30'],
        'title': 'Sales with Moving Averages'
    },
    {
        'chart_type': 'line',
        'x': 'Date',
        'y': 'Growth_Rate',
        'title': 'Daily Growth Rate (%)',
        'color': 'green'
    },
    {
        'chart_type': 'histogram',
        'y': 'Sales',
        'title': 'Sales Distribution',
        'bins': 50
    },
    {
        'chart_type': 'box',
        'y': 'Sales',
        'title': 'Sales Box Plot'
    }
]

# Prepare data for multi-chart (convert dates to strings)
df_plot = df.copy()
df_plot['Date'] = df_plot['Date'].dt.strftime('%Y-%m-%d')

fig = create_multi_chart(df_plot, charts_config, layout=(2, 2),
                        suptitle='Time Series Analysis Dashboard')
save_chart(fig, 'time_series_dashboard.png')

# 7. Statistical summary
print("\nTime Series Statistics:")
print(f"Mean: ${df['Sales'].mean():,.2f}")
print(f"Median: ${df['Sales'].median():,.2f}")
print(f"Std Dev: ${df['Sales'].std():,.2f}")
print(f"Min: ${df['Sales'].min():,.2f}")
print(f"Max: ${df['Sales'].max():,.2f}")
print(f"Total Days: {len(df)}")
print(f"Upward Trend Days: {(df['Trend'] == 'Upward').sum()}")
print(f"Downward Trend Days: {(df['Trend'] == 'Downward').sum()}")

# 8. Save analysis
save_to_excel(
    {'Daily Data': df, 'Summary': df.describe()},
    'time_series_analysis.xlsx'
)
```

## Example 6: Customer Cohort Analysis

### Scenario
Analyze customer behavior by cohorts based on first purchase date.

### Solution

```python
# 1. Load transaction data
transactions = read_file('transactions.xlsx')
transactions['TransactionDate'] = pd.to_datetime(transactions['TransactionDate'])

# 2. Identify first purchase for each customer
first_purchase = transactions.groupby('CustomerID')['TransactionDate'].min().reset_index()
first_purchase.columns = ['CustomerID', 'CohortDate']

# 3. Merge cohort info back
transactions = pd.merge(transactions, first_purchase, on='CustomerID')

# 4. Create cohort month
transactions['CohortMonth'] = transactions['CohortDate'].dt.to_period('M')
transactions['TransactionMonth'] = transactions['TransactionDate'].dt.to_period('M')

# 5. Calculate months since first purchase
transactions['MonthsSinceFirst'] = (
    (transactions['TransactionMonth'] - transactions['CohortMonth']).apply(lambda x: x.n)
)

# 6. Create cohort analysis pivot
cohort_counts = create_pivot(
    transactions,
    index='CohortMonth',
    columns='MonthsSinceFirst',
    values='CustomerID',
    aggfunc='nunique'
)

# Calculate retention rate
cohort_sizes = cohort_counts.iloc[:, 0]
retention_matrix = cohort_counts.divide(cohort_sizes, axis=0) * 100

# 7. Create heatmap
from visualization import create_chart

fig = create_chart(
    retention_matrix,
    chart_type='heatmap',
    title='Customer Retention Rate by Cohort (%)',
    figsize=(14, 10),
    color='RdYlGn'
)
save_chart(fig, 'cohort_retention.png')

# 8. Save analysis
save_to_excel(
    {
        'Transactions': transactions,
        'Cohort Counts': cohort_counts,
        'Retention %': retention_matrix
    },
    'cohort_analysis.xlsx'
)
```

## Tips for Advanced Usage

1. **Chain operations**: Combine multiple transformations efficiently
2. **Use method chaining**: Leverage pandas method chaining for cleaner code
3. **Profile large datasets**: Use `df.info()` and `df.memory_usage()` to optimize
4. **Vectorize operations**: Avoid loops, use pandas vectorized functions
5. **Cache intermediate results**: Save processed data to avoid reprocessing
6. **Document assumptions**: Add comments explaining business logic
7. **Validate results**: Always check output makes business sense
8. **Use version control**: Track changes to analysis scripts

## Performance Optimization

For large datasets (>1M rows):

```python
# Read in chunks
chunk_size = 100000
chunks = []
for chunk in pd.read_csv('large_file.csv', chunksize=chunk_size):
    processed = process_chunk(chunk)
    chunks.append(processed)
result = pd.concat(chunks)

# Use categorical data types for repeated strings
df['Category'] = df['Category'].astype('category')

# Use appropriate dtypes
df['ID'] = df['ID'].astype('int32')  # instead of int64 if values fit

# Filter early
df = df[df['Date'] >= '2024-01-01']  # Before expensive operations
```
